﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Axxen
{
    public partial class MDS_SDS_007 : Axxen.BaseForm
    {
        public MDS_SDS_007()
        {
            InitializeComponent();
        }
    }
}
