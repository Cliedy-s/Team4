﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Axxen
{
    public partial class QAM_SQC_001 : Axxen.GridGridForm
    {
        public QAM_SQC_001()
        {
            InitializeComponent();
        }
    }
}
