﻿using AxxenClient.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AxxenClient.Templets
{
    public partial class ClientBaseForm : BaseForm
    {
        public ClientBaseForm()
        {
            InitializeComponent();
        }

        private void aButton2_Click(object sender, EventArgs e)
        {

        }

        private void ClientBaseForm_Load(object sender, EventArgs e)
        {
        }

        private void btnNoActive_Click(object sender, EventArgs e)
        {
            
        }
    }
}
