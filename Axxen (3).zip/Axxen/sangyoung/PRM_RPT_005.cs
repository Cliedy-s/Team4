﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Axxen
{
    public partial class PRM_RPT_005 : Axxen.ReportForm
    {
        public PRM_RPT_005()
        {
            InitializeComponent();
        }
    }
}
