﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FORTEST_03_CLIENT.Service
{
    class ProductService : ServiceParent
    {
        public ProductService() : base("api/Product") { }
    }
}
