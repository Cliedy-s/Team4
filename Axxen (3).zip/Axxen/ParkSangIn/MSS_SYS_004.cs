﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Axxen
{
    public partial class MSS_SYS_004 : Axxen.BaseForm
    {
        public MSS_SYS_004()
        {
            InitializeComponent();
        }

        private void MSS_SYS_004_Load(object sender, EventArgs e)
        {

        }
    }
}
