﻿namespace Axxen
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.aPanel1 = new Axxen.CustomControls.APanel();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.aPanel2 = new Axxen.CustomControls.APanel();
            this.btnBookmark = new System.Windows.Forms.Button();
            this.tvMenu = new System.Windows.Forms.TreeView();
            this.ctmBookMark = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.즐겨찾기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button7 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.시스템관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.사용자그룹관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.사용자그룹별권한설정ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.사용자관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.메뉴관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.모듈관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.화면관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.로그인이력정보ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iPAddress관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.시스템코드대분류ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.시스템코드상세분류ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.공지사항등록ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.기준정보관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.공정정보ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.작업장정보ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.품목분류정보ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.품목정보ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iPC정보ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.etherIO정보ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.etherIO정보ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.품질규격설정ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.공정조건설정ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.분량현상대분류ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.불량현상상세분류ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.비가동대분류ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.비가동상세분류ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.사용자정의코드대분류ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.사용자정의코드상세분류ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.포장등급상세정의ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.대차정보ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.작업지시관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.성형작업지시생성ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.작업지시생성마감ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.시간대별실적조회ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.일단위시간대별실적조회ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.실적관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.실적조회ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.포장팔레트마감ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.완제품입고리스트ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gAS사용량등록ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.대차현황ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.대차이력조회ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.대차현황모니터링ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.비가동등록ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eRP근태정보조회ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.근태현황분석ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.품질관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.불량이미지등록ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.품질측정값등록ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.공정조건등록ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.품질측정값조회ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.공정조건조회ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.원재료LOT관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.일지관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.적재작업일지ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.성형작업일지ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.포장작업일지ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.선별포장작업일지ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.소성작업일지ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.분석관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.일별생산현황ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.월별생산현황ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.월별수율현황ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.포장월간실적현황ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.표준생산정보등록ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.금형관리ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.금형정보ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.금형사용현황ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.전체닫기ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.aLabel2 = new Axxen.CustomControls.ALabel();
            this.lblSubtitle = new Axxen.CustomControls.ALabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbInsert = new System.Windows.Forms.ToolStripButton();
            this.tsbtnUpdate = new System.Windows.Forms.ToolStripButton();
            this.tsbtnDelete = new System.Windows.Forms.ToolStripButton();
            this.tsbtnPrint = new System.Windows.Forms.ToolStripButton();
            this.tsbtnSave = new System.Windows.Forms.ToolStripButton();
            this.tsbtnRefresh = new System.Windows.Forms.ToolStripButton();
            this.aLabel1 = new Axxen.CustomControls.ALabel();
            this.lblName = new Axxen.CustomControls.ALabel();
            this.pnBookmark = new Axxen.CustomControls.APanel();
            this.tvBookMark = new System.Windows.Forms.TreeView();
            this.txtnotice = new Axxen.CustomControls.ATextBox();
            this.panelMenu.SuspendLayout();
            this.aPanel1.SuspendLayout();
            this.aPanel2.SuspendLayout();
            this.ctmBookMark.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.pnBookmark.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.White;
            this.panelMenu.Controls.Add(this.aPanel1);
            this.panelMenu.Controls.Add(this.button8);
            this.panelMenu.Controls.Add(this.aPanel2);
            this.panelMenu.Controls.Add(this.tvMenu);
            this.panelMenu.Controls.Add(this.button7);
            this.panelMenu.Controls.Add(this.button1);
            this.panelMenu.Controls.Add(this.button3);
            this.panelMenu.Controls.Add(this.button6);
            this.panelMenu.Controls.Add(this.button4);
            this.panelMenu.Controls.Add(this.button5);
            this.panelMenu.Controls.Add(this.button2);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 111);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(267, 833);
            this.panelMenu.TabIndex = 5;
            // 
            // aPanel1
            // 
            this.aPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.aPanel1.Controls.Add(this.button9);
            this.aPanel1.Location = new System.Drawing.Point(4, -1);
            this.aPanel1.Name = "aPanel1";
            this.aPanel1.Size = new System.Drawing.Size(261, 43);
            this.aPanel1.TabIndex = 10;
            // 
            // button9
            // 
            this.button9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(239)))), ((int)(((byte)(245)))));
            this.button9.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button9.ForeColor = System.Drawing.Color.Black;
            this.button9.Location = new System.Drawing.Point(2, 3);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(256, 37);
            this.button9.TabIndex = 8;
            this.button9.Text = "메뉴";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button8.Location = new System.Drawing.Point(3, 216);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(263, 37);
            this.button8.TabIndex = 5;
            this.button8.Text = "일지관리";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.BtnMenu_Click);
            // 
            // aPanel2
            // 
            this.aPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.aPanel2.Controls.Add(this.btnBookmark);
            this.aPanel2.Location = new System.Drawing.Point(3, 787);
            this.aPanel2.Name = "aPanel2";
            this.aPanel2.Size = new System.Drawing.Size(261, 43);
            this.aPanel2.TabIndex = 9;
            // 
            // btnBookmark
            // 
            this.btnBookmark.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBookmark.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBookmark.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBookmark.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnBookmark.Location = new System.Drawing.Point(2, 3);
            this.btnBookmark.Name = "btnBookmark";
            this.btnBookmark.Size = new System.Drawing.Size(256, 37);
            this.btnBookmark.TabIndex = 8;
            this.btnBookmark.Text = "즐겨찾기";
            this.btnBookmark.UseVisualStyleBackColor = false;
            this.btnBookmark.Click += new System.EventHandler(this.BtnBookmark_Click);
            // 
            // tvMenu
            // 
            this.tvMenu.BackColor = System.Drawing.Color.White;
            this.tvMenu.ContextMenuStrip = this.ctmBookMark;
            this.tvMenu.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tvMenu.Location = new System.Drawing.Point(3, 324);
            this.tvMenu.Name = "tvMenu";
            this.tvMenu.Size = new System.Drawing.Size(261, 464);
            this.tvMenu.TabIndex = 7;
            this.tvMenu.DoubleClick += new System.EventHandler(this.TvMenu_DoubleClick);
            // 
            // ctmBookMark
            // 
            this.ctmBookMark.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.즐겨찾기ToolStripMenuItem});
            this.ctmBookMark.Name = "contextMenuStrip";
            this.ctmBookMark.Size = new System.Drawing.Size(123, 26);
            // 
            // 즐겨찾기ToolStripMenuItem
            // 
            this.즐겨찾기ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("즐겨찾기ToolStripMenuItem.Image")));
            this.즐겨찾기ToolStripMenuItem.Name = "즐겨찾기ToolStripMenuItem";
            this.즐겨찾기ToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.즐겨찾기ToolStripMenuItem.Text = "즐겨찾기";
            this.즐겨찾기ToolStripMenuItem.Click += new System.EventHandler(this.즐겨찾기ToolStripMenuItem_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button7.Location = new System.Drawing.Point(4, 288);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(261, 37);
            this.button7.TabIndex = 7;
            this.button7.Text = "금형관리";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.BtnMenu_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(3, 41);
            this.button1.Margin = new System.Windows.Forms.Padding(5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(261, 37);
            this.button1.TabIndex = 0;
            this.button1.Text = "시스템관리";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.BtnMenu_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3.Location = new System.Drawing.Point(3, 111);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(261, 37);
            this.button3.TabIndex = 2;
            this.button3.Text = "작업지시관리";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.BtnMenu_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button6.Location = new System.Drawing.Point(4, 252);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(261, 37);
            this.button6.TabIndex = 6;
            this.button6.Text = "분석관리";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.BtnMenu_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button4.Location = new System.Drawing.Point(3, 146);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(261, 37);
            this.button4.TabIndex = 3;
            this.button4.Text = "실적관리";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.BtnMenu_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button5.Location = new System.Drawing.Point(4, 181);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(261, 37);
            this.button5.TabIndex = 4;
            this.button5.Text = "품질관리";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.BtnMenu_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button2.Location = new System.Drawing.Point(3, 76);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(261, 37);
            this.button2.TabIndex = 1;
            this.button2.Text = "기준정보관리";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.BtnMenu_Click);
            // 
            // 시스템관리ToolStripMenuItem
            // 
            this.시스템관리ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.사용자그룹관리ToolStripMenuItem,
            this.사용자그룹별권한설정ToolStripMenuItem,
            this.사용자관리ToolStripMenuItem,
            this.메뉴관리ToolStripMenuItem,
            this.모듈관리ToolStripMenuItem,
            this.화면관리ToolStripMenuItem,
            this.로그인이력정보ToolStripMenuItem,
            this.iPAddress관리ToolStripMenuItem,
            this.시스템코드대분류ToolStripMenuItem,
            this.시스템코드상세분류ToolStripMenuItem,
            this.공지사항등록ToolStripMenuItem});
            this.시스템관리ToolStripMenuItem.Name = "시스템관리ToolStripMenuItem";
            this.시스템관리ToolStripMenuItem.Size = new System.Drawing.Size(79, 30);
            this.시스템관리ToolStripMenuItem.Text = "시스템관리";
            // 
            // 사용자그룹관리ToolStripMenuItem
            // 
            this.사용자그룹관리ToolStripMenuItem.Name = "사용자그룹관리ToolStripMenuItem";
            this.사용자그룹관리ToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.사용자그룹관리ToolStripMenuItem.Text = "사용자그룹관리";
            this.사용자그룹관리ToolStripMenuItem.Click += new System.EventHandler(this.사용자그룹관리ToolStripMenuItem_Click);
            // 
            // 사용자그룹별권한설정ToolStripMenuItem
            // 
            this.사용자그룹별권한설정ToolStripMenuItem.Name = "사용자그룹별권한설정ToolStripMenuItem";
            this.사용자그룹별권한설정ToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.사용자그룹별권한설정ToolStripMenuItem.Text = "사용자그룹별 권한 설정";
            // 
            // 사용자관리ToolStripMenuItem
            // 
            this.사용자관리ToolStripMenuItem.Name = "사용자관리ToolStripMenuItem";
            this.사용자관리ToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.사용자관리ToolStripMenuItem.Text = "사용자관리";
            // 
            // 메뉴관리ToolStripMenuItem
            // 
            this.메뉴관리ToolStripMenuItem.Name = "메뉴관리ToolStripMenuItem";
            this.메뉴관리ToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.메뉴관리ToolStripMenuItem.Text = "메뉴관리";
            // 
            // 모듈관리ToolStripMenuItem
            // 
            this.모듈관리ToolStripMenuItem.Name = "모듈관리ToolStripMenuItem";
            this.모듈관리ToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.모듈관리ToolStripMenuItem.Text = "모듈관리";
            // 
            // 화면관리ToolStripMenuItem
            // 
            this.화면관리ToolStripMenuItem.Name = "화면관리ToolStripMenuItem";
            this.화면관리ToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.화면관리ToolStripMenuItem.Text = "화면관리";
            // 
            // 로그인이력정보ToolStripMenuItem
            // 
            this.로그인이력정보ToolStripMenuItem.Name = "로그인이력정보ToolStripMenuItem";
            this.로그인이력정보ToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.로그인이력정보ToolStripMenuItem.Text = "로그인이력정보";
            // 
            // iPAddress관리ToolStripMenuItem
            // 
            this.iPAddress관리ToolStripMenuItem.Name = "iPAddress관리ToolStripMenuItem";
            this.iPAddress관리ToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.iPAddress관리ToolStripMenuItem.Text = "IP Address 관리";
            // 
            // 시스템코드대분류ToolStripMenuItem
            // 
            this.시스템코드대분류ToolStripMenuItem.Name = "시스템코드대분류ToolStripMenuItem";
            this.시스템코드대분류ToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.시스템코드대분류ToolStripMenuItem.Text = "시스템코드 대분류";
            // 
            // 시스템코드상세분류ToolStripMenuItem
            // 
            this.시스템코드상세분류ToolStripMenuItem.Name = "시스템코드상세분류ToolStripMenuItem";
            this.시스템코드상세분류ToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.시스템코드상세분류ToolStripMenuItem.Text = "시스템코드 상세분류";
            // 
            // 공지사항등록ToolStripMenuItem
            // 
            this.공지사항등록ToolStripMenuItem.Name = "공지사항등록ToolStripMenuItem";
            this.공지사항등록ToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.공지사항등록ToolStripMenuItem.Text = "공지사항등록";
            // 
            // 기준정보관리ToolStripMenuItem
            // 
            this.기준정보관리ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.공정정보ToolStripMenuItem,
            this.작업장정보ToolStripMenuItem,
            this.품목분류정보ToolStripMenuItem,
            this.품목정보ToolStripMenuItem,
            this.iPC정보ToolStripMenuItem,
            this.etherIO정보ToolStripMenuItem,
            this.etherIO정보ToolStripMenuItem1,
            this.품질규격설정ToolStripMenuItem,
            this.공정조건설정ToolStripMenuItem,
            this.분량현상대분류ToolStripMenuItem,
            this.불량현상상세분류ToolStripMenuItem,
            this.비가동대분류ToolStripMenuItem,
            this.비가동상세분류ToolStripMenuItem,
            this.사용자정의코드대분류ToolStripMenuItem,
            this.사용자정의코드상세분류ToolStripMenuItem,
            this.포장등급상세정의ToolStripMenuItem,
            this.대차정보ToolStripMenuItem});
            this.기준정보관리ToolStripMenuItem.Name = "기준정보관리ToolStripMenuItem";
            this.기준정보관리ToolStripMenuItem.Size = new System.Drawing.Size(91, 30);
            this.기준정보관리ToolStripMenuItem.Text = "기준정보관리";
            // 
            // 공정정보ToolStripMenuItem
            // 
            this.공정정보ToolStripMenuItem.Name = "공정정보ToolStripMenuItem";
            this.공정정보ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.공정정보ToolStripMenuItem.Text = "공정정보";
            // 
            // 작업장정보ToolStripMenuItem
            // 
            this.작업장정보ToolStripMenuItem.Name = "작업장정보ToolStripMenuItem";
            this.작업장정보ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.작업장정보ToolStripMenuItem.Text = "작업장정보";
            // 
            // 품목분류정보ToolStripMenuItem
            // 
            this.품목분류정보ToolStripMenuItem.Name = "품목분류정보ToolStripMenuItem";
            this.품목분류정보ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.품목분류정보ToolStripMenuItem.Text = "품목분류정보";
            // 
            // 품목정보ToolStripMenuItem
            // 
            this.품목정보ToolStripMenuItem.Name = "품목정보ToolStripMenuItem";
            this.품목정보ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.품목정보ToolStripMenuItem.Text = "품목정보";
            // 
            // iPC정보ToolStripMenuItem
            // 
            this.iPC정보ToolStripMenuItem.Name = "iPC정보ToolStripMenuItem";
            this.iPC정보ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.iPC정보ToolStripMenuItem.Text = "IPC 정보";
            // 
            // etherIO정보ToolStripMenuItem
            // 
            this.etherIO정보ToolStripMenuItem.Name = "etherIO정보ToolStripMenuItem";
            this.etherIO정보ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.etherIO정보ToolStripMenuItem.Text = "Ether IO 정보";
            // 
            // etherIO정보ToolStripMenuItem1
            // 
            this.etherIO정보ToolStripMenuItem1.Name = "etherIO정보ToolStripMenuItem1";
            this.etherIO정보ToolStripMenuItem1.Size = new System.Drawing.Size(210, 22);
            this.etherIO정보ToolStripMenuItem1.Text = "Ether IO채널정보";
            // 
            // 품질규격설정ToolStripMenuItem
            // 
            this.품질규격설정ToolStripMenuItem.Name = "품질규격설정ToolStripMenuItem";
            this.품질규격설정ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.품질규격설정ToolStripMenuItem.Text = "품질규격 설정";
            // 
            // 공정조건설정ToolStripMenuItem
            // 
            this.공정조건설정ToolStripMenuItem.Name = "공정조건설정ToolStripMenuItem";
            this.공정조건설정ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.공정조건설정ToolStripMenuItem.Text = "공정조건 설정";
            // 
            // 분량현상대분류ToolStripMenuItem
            // 
            this.분량현상대분류ToolStripMenuItem.Name = "분량현상대분류ToolStripMenuItem";
            this.분량현상대분류ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.분량현상대분류ToolStripMenuItem.Text = "불량현상 대분류";
            // 
            // 불량현상상세분류ToolStripMenuItem
            // 
            this.불량현상상세분류ToolStripMenuItem.Name = "불량현상상세분류ToolStripMenuItem";
            this.불량현상상세분류ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.불량현상상세분류ToolStripMenuItem.Text = "불량현상 상세분류";
            // 
            // 비가동대분류ToolStripMenuItem
            // 
            this.비가동대분류ToolStripMenuItem.Name = "비가동대분류ToolStripMenuItem";
            this.비가동대분류ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.비가동대분류ToolStripMenuItem.Text = "비가동 대분류";
            // 
            // 비가동상세분류ToolStripMenuItem
            // 
            this.비가동상세분류ToolStripMenuItem.Name = "비가동상세분류ToolStripMenuItem";
            this.비가동상세분류ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.비가동상세분류ToolStripMenuItem.Text = "비가동 상세분류";
            // 
            // 사용자정의코드대분류ToolStripMenuItem
            // 
            this.사용자정의코드대분류ToolStripMenuItem.Name = "사용자정의코드대분류ToolStripMenuItem";
            this.사용자정의코드대분류ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.사용자정의코드대분류ToolStripMenuItem.Text = "사용자정의코드 대분류";
            // 
            // 사용자정의코드상세분류ToolStripMenuItem
            // 
            this.사용자정의코드상세분류ToolStripMenuItem.Name = "사용자정의코드상세분류ToolStripMenuItem";
            this.사용자정의코드상세분류ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.사용자정의코드상세분류ToolStripMenuItem.Text = "사용자정의코드 상세분류";
            // 
            // 포장등급상세정의ToolStripMenuItem
            // 
            this.포장등급상세정의ToolStripMenuItem.Name = "포장등급상세정의ToolStripMenuItem";
            this.포장등급상세정의ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.포장등급상세정의ToolStripMenuItem.Text = "포장등급 상세정의";
            // 
            // 대차정보ToolStripMenuItem
            // 
            this.대차정보ToolStripMenuItem.Name = "대차정보ToolStripMenuItem";
            this.대차정보ToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.대차정보ToolStripMenuItem.Text = "대차정보";
            // 
            // 작업지시관리ToolStripMenuItem
            // 
            this.작업지시관리ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.성형작업지시생성ToolStripMenuItem,
            this.작업지시생성마감ToolStripMenuItem,
            this.시간대별실적조회ToolStripMenuItem,
            this.일단위시간대별실적조회ToolStripMenuItem});
            this.작업지시관리ToolStripMenuItem.Name = "작업지시관리ToolStripMenuItem";
            this.작업지시관리ToolStripMenuItem.Size = new System.Drawing.Size(91, 30);
            this.작업지시관리ToolStripMenuItem.Text = "작업지시관리";
            // 
            // 성형작업지시생성ToolStripMenuItem
            // 
            this.성형작업지시생성ToolStripMenuItem.Name = "성형작업지시생성ToolStripMenuItem";
            this.성형작업지시생성ToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.성형작업지시생성ToolStripMenuItem.Text = "성형작업지시생성";
            // 
            // 작업지시생성마감ToolStripMenuItem
            // 
            this.작업지시생성마감ToolStripMenuItem.Name = "작업지시생성마감ToolStripMenuItem";
            this.작업지시생성마감ToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.작업지시생성마감ToolStripMenuItem.Text = "작업지시 생성 마감";
            // 
            // 시간대별실적조회ToolStripMenuItem
            // 
            this.시간대별실적조회ToolStripMenuItem.Name = "시간대별실적조회ToolStripMenuItem";
            this.시간대별실적조회ToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.시간대별실적조회ToolStripMenuItem.Text = "시간대별 실적조회";
            // 
            // 일단위시간대별실적조회ToolStripMenuItem
            // 
            this.일단위시간대별실적조회ToolStripMenuItem.Name = "일단위시간대별실적조회ToolStripMenuItem";
            this.일단위시간대별실적조회ToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.일단위시간대별실적조회ToolStripMenuItem.Text = "일단위 시간대별 실적조회";
            // 
            // 실적관리ToolStripMenuItem
            // 
            this.실적관리ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.실적조회ToolStripMenuItem,
            this.포장팔레트마감ToolStripMenuItem,
            this.완제품입고리스트ToolStripMenuItem,
            this.gAS사용량등록ToolStripMenuItem,
            this.대차현황ToolStripMenuItem,
            this.대차이력조회ToolStripMenuItem,
            this.대차현황모니터링ToolStripMenuItem,
            this.비가동등록ToolStripMenuItem,
            this.eRP근태정보조회ToolStripMenuItem,
            this.근태현황분석ToolStripMenuItem});
            this.실적관리ToolStripMenuItem.Name = "실적관리ToolStripMenuItem";
            this.실적관리ToolStripMenuItem.Size = new System.Drawing.Size(67, 30);
            this.실적관리ToolStripMenuItem.Text = "실적관리";
            // 
            // 실적조회ToolStripMenuItem
            // 
            this.실적조회ToolStripMenuItem.Name = "실적조회ToolStripMenuItem";
            this.실적조회ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.실적조회ToolStripMenuItem.Text = "실적조회";
            // 
            // 포장팔레트마감ToolStripMenuItem
            // 
            this.포장팔레트마감ToolStripMenuItem.Name = "포장팔레트마감ToolStripMenuItem";
            this.포장팔레트마감ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.포장팔레트마감ToolStripMenuItem.Text = "포장 팔레트 마감";
            // 
            // 완제품입고리스트ToolStripMenuItem
            // 
            this.완제품입고리스트ToolStripMenuItem.Name = "완제품입고리스트ToolStripMenuItem";
            this.완제품입고리스트ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.완제품입고리스트ToolStripMenuItem.Text = "완제품 입고리스트";
            // 
            // gAS사용량등록ToolStripMenuItem
            // 
            this.gAS사용량등록ToolStripMenuItem.Name = "gAS사용량등록ToolStripMenuItem";
            this.gAS사용량등록ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.gAS사용량등록ToolStripMenuItem.Text = "GAS 사용량 등록";
            // 
            // 대차현황ToolStripMenuItem
            // 
            this.대차현황ToolStripMenuItem.Name = "대차현황ToolStripMenuItem";
            this.대차현황ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.대차현황ToolStripMenuItem.Text = "대차 현황";
            // 
            // 대차이력조회ToolStripMenuItem
            // 
            this.대차이력조회ToolStripMenuItem.Name = "대차이력조회ToolStripMenuItem";
            this.대차이력조회ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.대차이력조회ToolStripMenuItem.Text = "대차 이력조회";
            // 
            // 대차현황모니터링ToolStripMenuItem
            // 
            this.대차현황모니터링ToolStripMenuItem.Name = "대차현황모니터링ToolStripMenuItem";
            this.대차현황모니터링ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.대차현황모니터링ToolStripMenuItem.Text = "대차현황 모니터링";
            // 
            // 비가동등록ToolStripMenuItem
            // 
            this.비가동등록ToolStripMenuItem.Name = "비가동등록ToolStripMenuItem";
            this.비가동등록ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.비가동등록ToolStripMenuItem.Text = "비가동 등록";
            // 
            // eRP근태정보조회ToolStripMenuItem
            // 
            this.eRP근태정보조회ToolStripMenuItem.Name = "eRP근태정보조회ToolStripMenuItem";
            this.eRP근태정보조회ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.eRP근태정보조회ToolStripMenuItem.Text = "ERP 근태정보 조회";
            // 
            // 근태현황분석ToolStripMenuItem
            // 
            this.근태현황분석ToolStripMenuItem.Name = "근태현황분석ToolStripMenuItem";
            this.근태현황분석ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.근태현황분석ToolStripMenuItem.Text = "근태현황분석";
            // 
            // 품질관리ToolStripMenuItem
            // 
            this.품질관리ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.불량이미지등록ToolStripMenuItem,
            this.품질측정값등록ToolStripMenuItem,
            this.공정조건등록ToolStripMenuItem,
            this.품질측정값조회ToolStripMenuItem,
            this.공정조건조회ToolStripMenuItem,
            this.원재료LOT관리ToolStripMenuItem});
            this.품질관리ToolStripMenuItem.Name = "품질관리ToolStripMenuItem";
            this.품질관리ToolStripMenuItem.Size = new System.Drawing.Size(67, 30);
            this.품질관리ToolStripMenuItem.Text = "품질관리";
            // 
            // 불량이미지등록ToolStripMenuItem
            // 
            this.불량이미지등록ToolStripMenuItem.Name = "불량이미지등록ToolStripMenuItem";
            this.불량이미지등록ToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.불량이미지등록ToolStripMenuItem.Text = "불량이미지 등록";
            // 
            // 품질측정값등록ToolStripMenuItem
            // 
            this.품질측정값등록ToolStripMenuItem.Name = "품질측정값등록ToolStripMenuItem";
            this.품질측정값등록ToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.품질측정값등록ToolStripMenuItem.Text = "품질측정값 등록";
            // 
            // 공정조건등록ToolStripMenuItem
            // 
            this.공정조건등록ToolStripMenuItem.Name = "공정조건등록ToolStripMenuItem";
            this.공정조건등록ToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.공정조건등록ToolStripMenuItem.Text = "공정조건 등록";
            // 
            // 품질측정값조회ToolStripMenuItem
            // 
            this.품질측정값조회ToolStripMenuItem.Name = "품질측정값조회ToolStripMenuItem";
            this.품질측정값조회ToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.품질측정값조회ToolStripMenuItem.Text = "품질측정값 조회";
            // 
            // 공정조건조회ToolStripMenuItem
            // 
            this.공정조건조회ToolStripMenuItem.Name = "공정조건조회ToolStripMenuItem";
            this.공정조건조회ToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.공정조건조회ToolStripMenuItem.Text = "공정조건 조회";
            // 
            // 원재료LOT관리ToolStripMenuItem
            // 
            this.원재료LOT관리ToolStripMenuItem.Name = "원재료LOT관리ToolStripMenuItem";
            this.원재료LOT관리ToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.원재료LOT관리ToolStripMenuItem.Text = "원재료 LOT관리";
            // 
            // 일지관리ToolStripMenuItem
            // 
            this.일지관리ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.적재작업일지ToolStripMenuItem,
            this.성형작업일지ToolStripMenuItem,
            this.포장작업일지ToolStripMenuItem,
            this.선별포장작업일지ToolStripMenuItem,
            this.소성작업일지ToolStripMenuItem});
            this.일지관리ToolStripMenuItem.Name = "일지관리ToolStripMenuItem";
            this.일지관리ToolStripMenuItem.Size = new System.Drawing.Size(67, 30);
            this.일지관리ToolStripMenuItem.Text = "일지관리";
            // 
            // 적재작업일지ToolStripMenuItem
            // 
            this.적재작업일지ToolStripMenuItem.Name = "적재작업일지ToolStripMenuItem";
            this.적재작업일지ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.적재작업일지ToolStripMenuItem.Text = "적재작업일지";
            // 
            // 성형작업일지ToolStripMenuItem
            // 
            this.성형작업일지ToolStripMenuItem.Name = "성형작업일지ToolStripMenuItem";
            this.성형작업일지ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.성형작업일지ToolStripMenuItem.Text = "성형작업일지";
            // 
            // 포장작업일지ToolStripMenuItem
            // 
            this.포장작업일지ToolStripMenuItem.Name = "포장작업일지ToolStripMenuItem";
            this.포장작업일지ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.포장작업일지ToolStripMenuItem.Text = "포장작업일지";
            // 
            // 선별포장작업일지ToolStripMenuItem
            // 
            this.선별포장작업일지ToolStripMenuItem.Name = "선별포장작업일지ToolStripMenuItem";
            this.선별포장작업일지ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.선별포장작업일지ToolStripMenuItem.Text = "선별/포장작업일지";
            // 
            // 소성작업일지ToolStripMenuItem
            // 
            this.소성작업일지ToolStripMenuItem.Name = "소성작업일지ToolStripMenuItem";
            this.소성작업일지ToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.소성작업일지ToolStripMenuItem.Text = "소성작업일지";
            // 
            // 분석관리ToolStripMenuItem
            // 
            this.분석관리ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.일별생산현황ToolStripMenuItem,
            this.월별생산현황ToolStripMenuItem,
            this.월별수율현황ToolStripMenuItem,
            this.포장월간실적현황ToolStripMenuItem,
            this.표준생산정보등록ToolStripMenuItem});
            this.분석관리ToolStripMenuItem.Name = "분석관리ToolStripMenuItem";
            this.분석관리ToolStripMenuItem.Size = new System.Drawing.Size(67, 30);
            this.분석관리ToolStripMenuItem.Text = "분석관리";
            // 
            // 일별생산현황ToolStripMenuItem
            // 
            this.일별생산현황ToolStripMenuItem.Name = "일별생산현황ToolStripMenuItem";
            this.일별생산현황ToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.일별생산현황ToolStripMenuItem.Text = "일별 생산현황";
            // 
            // 월별생산현황ToolStripMenuItem
            // 
            this.월별생산현황ToolStripMenuItem.Name = "월별생산현황ToolStripMenuItem";
            this.월별생산현황ToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.월별생산현황ToolStripMenuItem.Text = "월별 생산현황";
            // 
            // 월별수율현황ToolStripMenuItem
            // 
            this.월별수율현황ToolStripMenuItem.Name = "월별수율현황ToolStripMenuItem";
            this.월별수율현황ToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.월별수율현황ToolStripMenuItem.Text = "월별 수율현황";
            // 
            // 포장월간실적현황ToolStripMenuItem
            // 
            this.포장월간실적현황ToolStripMenuItem.Name = "포장월간실적현황ToolStripMenuItem";
            this.포장월간실적현황ToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.포장월간실적현황ToolStripMenuItem.Text = "포장 월간 실적현황";
            // 
            // 표준생산정보등록ToolStripMenuItem
            // 
            this.표준생산정보등록ToolStripMenuItem.Name = "표준생산정보등록ToolStripMenuItem";
            this.표준생산정보등록ToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.표준생산정보등록ToolStripMenuItem.Text = "표준생산정보등록";
            // 
            // 금형관리ToolStripMenuItem
            // 
            this.금형관리ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.금형정보ToolStripMenuItem,
            this.금형사용현황ToolStripMenuItem});
            this.금형관리ToolStripMenuItem.Name = "금형관리ToolStripMenuItem";
            this.금형관리ToolStripMenuItem.Size = new System.Drawing.Size(67, 30);
            this.금형관리ToolStripMenuItem.Text = "금형관리";
            // 
            // 금형정보ToolStripMenuItem
            // 
            this.금형정보ToolStripMenuItem.Name = "금형정보ToolStripMenuItem";
            this.금형정보ToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.금형정보ToolStripMenuItem.Text = "금형정보 등록";
            // 
            // 금형사용현황ToolStripMenuItem
            // 
            this.금형사용현황ToolStripMenuItem.Name = "금형사용현황ToolStripMenuItem";
            this.금형사용현황ToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.금형사용현황ToolStripMenuItem.Text = "금형 사용현황";
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.시스템관리ToolStripMenuItem,
            this.기준정보관리ToolStripMenuItem,
            this.작업지시관리ToolStripMenuItem,
            this.실적관리ToolStripMenuItem,
            this.품질관리ToolStripMenuItem,
            this.일지관리ToolStripMenuItem,
            this.분석관리ToolStripMenuItem,
            this.금형관리ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1616, 34);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tabControl2
            // 
            this.tabControl2.ContextMenuStrip = this.contextMenuStrip1;
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl2.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabControl2.Location = new System.Drawing.Point(267, 111);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1349, 24);
            this.tabControl2.TabIndex = 12;
            this.tabControl2.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.TabControl1_DrawItem);
            this.tabControl2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TabControl2_MouseClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.전체닫기ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(127, 26);
            // 
            // 전체닫기ToolStripMenuItem
            // 
            this.전체닫기ToolStripMenuItem.Name = "전체닫기ToolStripMenuItem";
            this.전체닫기ToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.전체닫기ToolStripMenuItem.Text = "전체 닫기";
            this.전체닫기ToolStripMenuItem.Click += new System.EventHandler(this.전체닫기ToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(239)))), ((int)(((byte)(245)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.aLabel2);
            this.panel1.Controls.Add(this.lblSubtitle);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(267, 898);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1349, 46);
            this.panel1.TabIndex = 20;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(7, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 30);
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // aLabel2
            // 
            this.aLabel2.AutoSize = true;
            this.aLabel2.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aLabel2.Location = new System.Drawing.Point(53, 18);
            this.aLabel2.Name = "aLabel2";
            this.aLabel2.Size = new System.Drawing.Size(73, 17);
            this.aLabel2.TabIndex = 20;
            this.aLabel2.Text = "위치 정보 :";
            // 
            // lblSubtitle
            // 
            this.lblSubtitle.AutoSize = true;
            this.lblSubtitle.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblSubtitle.Location = new System.Drawing.Point(118, 18);
            this.lblSubtitle.Name = "lblSubtitle";
            this.lblSubtitle.Size = new System.Drawing.Size(0, 17);
            this.lblSubtitle.TabIndex = 0;
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(239)))), ((int)(((byte)(245)))));
            this.toolStrip1.BackgroundImage = global::Axxen.Properties.Resources.MainBar;
            this.toolStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripSeparator1,
            this.tsbInsert,
            this.tsbtnUpdate,
            this.tsbtnDelete,
            this.tsbtnPrint,
            this.tsbtnSave,
            this.tsbtnRefresh});
            this.toolStrip1.Location = new System.Drawing.Point(0, 34);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1616, 77);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.AutoSize = false;
            this.toolStripButton1.BackColor = System.Drawing.Color.Transparent;
            this.toolStripButton1.BackgroundImage = global::Axxen.Properties.Resources.MianLoGo;
            this.toolStripButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.ForeColor = System.Drawing.Color.Transparent;
            this.toolStripButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(250, 70);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 77);
            // 
            // tsbInsert
            // 
            this.tsbInsert.AutoSize = false;
            this.tsbInsert.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tsbInsert.Image = ((System.Drawing.Image)(resources.GetObject("tsbInsert.Image")));
            this.tsbInsert.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbInsert.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbInsert.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbInsert.Name = "tsbInsert";
            this.tsbInsert.Size = new System.Drawing.Size(50, 57);
            this.tsbInsert.Text = "추가";
            this.tsbInsert.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbInsert.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.tsbInsert.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbInsert.ToolTipText = "조회";
            this.tsbInsert.Click += new System.EventHandler(this.TsbInsert_Click);
            // 
            // tsbtnUpdate
            // 
            this.tsbtnUpdate.AutoSize = false;
            this.tsbtnUpdate.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tsbtnUpdate.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnUpdate.Image")));
            this.tsbtnUpdate.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbtnUpdate.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbtnUpdate.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnUpdate.Name = "tsbtnUpdate";
            this.tsbtnUpdate.Size = new System.Drawing.Size(50, 57);
            this.tsbtnUpdate.Text = "수정";
            this.tsbtnUpdate.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbtnUpdate.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.tsbtnUpdate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbtnUpdate.ToolTipText = "조회";
            // 
            // tsbtnDelete
            // 
            this.tsbtnDelete.AutoSize = false;
            this.tsbtnDelete.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tsbtnDelete.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnDelete.Image")));
            this.tsbtnDelete.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbtnDelete.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbtnDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnDelete.Name = "tsbtnDelete";
            this.tsbtnDelete.Size = new System.Drawing.Size(50, 57);
            this.tsbtnDelete.Text = "삭제";
            this.tsbtnDelete.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbtnDelete.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.tsbtnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbtnDelete.ToolTipText = "조회";
            // 
            // tsbtnPrint
            // 
            this.tsbtnPrint.AutoSize = false;
            this.tsbtnPrint.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tsbtnPrint.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnPrint.Image")));
            this.tsbtnPrint.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbtnPrint.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbtnPrint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnPrint.Name = "tsbtnPrint";
            this.tsbtnPrint.Size = new System.Drawing.Size(50, 57);
            this.tsbtnPrint.Text = "출력";
            this.tsbtnPrint.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbtnPrint.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.tsbtnPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbtnPrint.ToolTipText = "조회";
            // 
            // tsbtnSave
            // 
            this.tsbtnSave.AutoSize = false;
            this.tsbtnSave.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tsbtnSave.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnSave.Image")));
            this.tsbtnSave.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbtnSave.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbtnSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnSave.Name = "tsbtnSave";
            this.tsbtnSave.Size = new System.Drawing.Size(50, 57);
            this.tsbtnSave.Text = "저장";
            this.tsbtnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbtnSave.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.tsbtnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbtnSave.ToolTipText = "조회";
            // 
            // tsbtnRefresh
            // 
            this.tsbtnRefresh.AutoSize = false;
            this.tsbtnRefresh.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tsbtnRefresh.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnRefresh.Image")));
            this.tsbtnRefresh.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.tsbtnRefresh.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbtnRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnRefresh.Name = "tsbtnRefresh";
            this.tsbtnRefresh.Size = new System.Drawing.Size(60, 57);
            this.tsbtnRefresh.Text = "새로고침";
            this.tsbtnRefresh.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tsbtnRefresh.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.tsbtnRefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbtnRefresh.ToolTipText = "조회";
            this.tsbtnRefresh.Click += new System.EventHandler(this.TsbtnRefresh_Click);
            // 
            // aLabel1
            // 
            this.aLabel1.AutoSize = true;
            this.aLabel1.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aLabel1.Location = new System.Drawing.Point(1469, 46);
            this.aLabel1.Name = "aLabel1";
            this.aLabel1.Size = new System.Drawing.Size(135, 19);
            this.aLabel1.TabIndex = 17;
            this.aLabel1.Text = "으로 로그인함.";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblName.Location = new System.Drawing.Point(1391, 46);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(47, 19);
            this.lblName.TabIndex = 15;
            this.lblName.Text = "이름";
            // 
            // pnBookmark
            // 
            this.pnBookmark.Controls.Add(this.tvBookMark);
            this.pnBookmark.Location = new System.Drawing.Point(267, 432);
            this.pnBookmark.Name = "pnBookmark";
            this.pnBookmark.Size = new System.Drawing.Size(200, 467);
            this.pnBookmark.TabIndex = 7;
            this.pnBookmark.Visible = false;
            // 
            // tvBookMark
            // 
            this.tvBookMark.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvBookMark.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tvBookMark.Location = new System.Drawing.Point(0, 0);
            this.tvBookMark.Name = "tvBookMark";
            this.tvBookMark.Size = new System.Drawing.Size(200, 467);
            this.tvBookMark.TabIndex = 0;
            // 
            // txtnotice
            // 
            this.txtnotice.BackColor = System.Drawing.Color.White;
            this.txtnotice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtnotice.errorp = null;
            this.txtnotice.Location = new System.Drawing.Point(1303, 69);
            this.txtnotice.Multiline = true;
            this.txtnotice.Name = "txtnotice";
            this.txtnotice.Size = new System.Drawing.Size(304, 37);
            this.txtnotice.TabIndex = 22;
            this.txtnotice.Text = "알림";
            this.txtnotice.txtType = Axxen.CustomControls.type.Normal;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1616, 944);
            this.Controls.Add(this.txtnotice);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.aLabel1);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.pnBookmark);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = " ";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panelMenu.ResumeLayout(false);
            this.aPanel1.ResumeLayout(false);
            this.aPanel2.ResumeLayout(false);
            this.ctmBookMark.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.pnBookmark.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.TreeView tvMenu;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem 시스템관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 사용자그룹관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 사용자그룹별권한설정ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 사용자관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 메뉴관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 모듈관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 화면관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 로그인이력정보ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iPAddress관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 시스템코드대분류ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 시스템코드상세분류ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 공지사항등록ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 기준정보관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 공정정보ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 작업장정보ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 품목분류정보ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 품목정보ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iPC정보ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem etherIO정보ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem etherIO정보ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 품질규격설정ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 공정조건설정ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 분량현상대분류ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 불량현상상세분류ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 비가동대분류ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 비가동상세분류ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 사용자정의코드대분류ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 사용자정의코드상세분류ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 포장등급상세정의ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 대차정보ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 작업지시관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 성형작업지시생성ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 작업지시생성마감ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 시간대별실적조회ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 일단위시간대별실적조회ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 실적관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 실적조회ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 포장팔레트마감ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 완제품입고리스트ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gAS사용량등록ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 대차현황ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 대차이력조회ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 대차현황모니터링ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 비가동등록ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eRP근태정보조회ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 근태현황분석ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 품질관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 불량이미지등록ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 품질측정값등록ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 공정조건등록ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 품질측정값조회ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 공정조건조회ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 원재료LOT관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 일지관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 적재작업일지ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 성형작업일지ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 포장작업일지ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 선별포장작업일지ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 소성작업일지ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 분석관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 일별생산현황ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 월별생산현황ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 월별수율현황ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 포장월간실적현황ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 표준생산정보등록ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 금형관리ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 금형정보ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 금형사용현황ToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private CustomControls.APanel aPanel2;
        private System.Windows.Forms.Button btnBookmark;
        private CustomControls.APanel pnBookmark;
        private System.Windows.Forms.ContextMenuStrip ctmBookMark;
        private System.Windows.Forms.ToolStripMenuItem 즐겨찾기ToolStripMenuItem;
        private System.Windows.Forms.Button button8;
        private CustomControls.APanel aPanel1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton tsbInsert;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private CustomControls.ALabel lblName;
        private CustomControls.ALabel aLabel1;
        private CustomControls.ALabel lblSubtitle;
        private CustomControls.ALabel aLabel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TreeView tvBookMark;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 전체닫기ToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton tsbtnUpdate;
        private System.Windows.Forms.ToolStripButton tsbtnDelete;
        private System.Windows.Forms.ToolStripButton tsbtnSave;
        private System.Windows.Forms.ToolStripButton tsbtnPrint;
        private System.Windows.Forms.ToolStripButton tsbtnRefresh;
        private CustomControls.ATextBox txtnotice;
    }
}