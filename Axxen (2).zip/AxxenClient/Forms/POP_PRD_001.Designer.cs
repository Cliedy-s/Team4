﻿namespace AxxenClient.Forms
{
    partial class WorkOrderForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.aDataGridView1 = new AxxenClient.CustomControls.ADataGridView();
            this.aPanel4 = new AxxenClient.CustomControls.APanel();
            this.aPanel5 = new AxxenClient.CustomControls.APanel();
            this.aPanel6 = new AxxenClient.CustomControls.APanel();
            this.aButton1 = new AxxenClient.CustomControls.AButton();
            this.aButton2 = new AxxenClient.CustomControls.AButton();
            this.aButton3 = new AxxenClient.CustomControls.AButton();
            this.aButton4 = new AxxenClient.CustomControls.AButton();
            this.aButton5 = new AxxenClient.CustomControls.AButton();
            this.aButton6 = new AxxenClient.CustomControls.AButton();
            this.aButton7 = new AxxenClient.CustomControls.AButton();
            this.aButton8 = new AxxenClient.CustomControls.AButton();
            this.aButton9 = new AxxenClient.CustomControls.AButton();
            this.aButton10 = new AxxenClient.CustomControls.AButton();
            this.aButton11 = new AxxenClient.CustomControls.AButton();
            this.aButton12 = new AxxenClient.CustomControls.AButton();
            this.aButton13 = new AxxenClient.CustomControls.AButton();
            this.aButton14 = new AxxenClient.CustomControls.AButton();
            this.aButton15 = new AxxenClient.CustomControls.AButton();
            this.aButton16 = new AxxenClient.CustomControls.AButton();
            this.aButton17 = new AxxenClient.CustomControls.AButton();
            this.aButton18 = new AxxenClient.CustomControls.AButton();
            this.aButton19 = new AxxenClient.CustomControls.AButton();
            this.aButton20 = new AxxenClient.CustomControls.AButton();
            this.aButton21 = new AxxenClient.CustomControls.AButton();
            this.aButton22 = new AxxenClient.CustomControls.AButton();
            this.aButton23 = new AxxenClient.CustomControls.AButton();
            this.aButton24 = new AxxenClient.CustomControls.AButton();
            this.aButton25 = new AxxenClient.CustomControls.AButton();
            this.aPanel1.SuspendLayout();
            this.aPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aDataGridView1)).BeginInit();
            this.aPanel4.SuspendLayout();
            this.aPanel5.SuspendLayout();
            this.aPanel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // aLabel_Header1
            // 
            this.aLabel_Header1.Text = "작업지시 현황";
            // 
            // aPanel1
            // 
            this.aPanel1.Location = new System.Drawing.Point(0, 983);
            // 
            // aDataGridView1
            // 
            this.aDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.aDataGridView1.Location = new System.Drawing.Point(12, 105);
            this.aDataGridView1.Name = "aDataGridView1";
            this.aDataGridView1.RowTemplate.Height = 23;
            this.aDataGridView1.Size = new System.Drawing.Size(1186, 482);
            this.aDataGridView1.TabIndex = 4;
            // 
            // aPanel4
            // 
            this.aPanel4.Controls.Add(this.aButton7);
            this.aPanel4.Controls.Add(this.aButton6);
            this.aPanel4.Controls.Add(this.aButton5);
            this.aPanel4.Controls.Add(this.aButton4);
            this.aPanel4.Controls.Add(this.aButton3);
            this.aPanel4.Controls.Add(this.aButton2);
            this.aPanel4.Controls.Add(this.aButton1);
            this.aPanel4.Location = new System.Drawing.Point(13, 593);
            this.aPanel4.Name = "aPanel4";
            this.aPanel4.Size = new System.Drawing.Size(1186, 124);
            this.aPanel4.TabIndex = 5;
            // 
            // aPanel5
            // 
            this.aPanel5.Controls.Add(this.aButton15);
            this.aPanel5.Controls.Add(this.aButton16);
            this.aPanel5.Controls.Add(this.aButton8);
            this.aPanel5.Controls.Add(this.aButton9);
            this.aPanel5.Controls.Add(this.aButton10);
            this.aPanel5.Controls.Add(this.aButton11);
            this.aPanel5.Controls.Add(this.aButton12);
            this.aPanel5.Controls.Add(this.aButton13);
            this.aPanel5.Controls.Add(this.aButton14);
            this.aPanel5.Location = new System.Drawing.Point(13, 723);
            this.aPanel5.Name = "aPanel5";
            this.aPanel5.Size = new System.Drawing.Size(1186, 124);
            this.aPanel5.TabIndex = 6;
            // 
            // aPanel6
            // 
            this.aPanel6.Controls.Add(this.aButton17);
            this.aPanel6.Controls.Add(this.aButton18);
            this.aPanel6.Controls.Add(this.aButton19);
            this.aPanel6.Controls.Add(this.aButton20);
            this.aPanel6.Controls.Add(this.aButton21);
            this.aPanel6.Controls.Add(this.aButton22);
            this.aPanel6.Controls.Add(this.aButton23);
            this.aPanel6.Controls.Add(this.aButton24);
            this.aPanel6.Controls.Add(this.aButton25);
            this.aPanel6.Location = new System.Drawing.Point(13, 853);
            this.aPanel6.Name = "aPanel6";
            this.aPanel6.Size = new System.Drawing.Size(1186, 124);
            this.aPanel6.TabIndex = 7;
            // 
            // aButton1
            // 
            this.aButton1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton1.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton1.Location = new System.Drawing.Point(978, 6);
            this.aButton1.Name = "aButton1";
            this.aButton1.Size = new System.Drawing.Size(145, 118);
            this.aButton1.TabIndex = 0;
            this.aButton1.Text = "품질\r\n측정값\r\n등록";
            this.aButton1.UseVisualStyleBackColor = false;
            // 
            // aButton2
            // 
            this.aButton2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton2.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton2.Location = new System.Drawing.Point(826, 6);
            this.aButton2.Name = "aButton2";
            this.aButton2.Size = new System.Drawing.Size(145, 118);
            this.aButton2.TabIndex = 1;
            this.aButton2.Text = "공정조건 등록";
            this.aButton2.UseVisualStyleBackColor = false;
            // 
            // aButton3
            // 
            this.aButton3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton3.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton3.Location = new System.Drawing.Point(674, 6);
            this.aButton3.Name = "aButton3";
            this.aButton3.Size = new System.Drawing.Size(145, 118);
            this.aButton3.TabIndex = 2;
            this.aButton3.Text = "금형 장착\r\n/탈착";
            this.aButton3.UseVisualStyleBackColor = false;
            // 
            // aButton4
            // 
            this.aButton4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton4.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton4.Location = new System.Drawing.Point(522, 6);
            this.aButton4.Name = "aButton4";
            this.aButton4.Size = new System.Drawing.Size(145, 118);
            this.aButton4.TabIndex = 3;
            this.aButton4.Text = "작업자\r\n할당";
            this.aButton4.UseVisualStyleBackColor = false;
            // 
            // aButton5
            // 
            this.aButton5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton5.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton5.Location = new System.Drawing.Point(370, 6);
            this.aButton5.Name = "aButton5";
            this.aButton5.Size = new System.Drawing.Size(145, 118);
            this.aButton5.TabIndex = 4;
            this.aButton5.Text = "건조 대차 로딩";
            this.aButton5.UseVisualStyleBackColor = false;
            // 
            // aButton6
            // 
            this.aButton6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton6.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton6.Location = new System.Drawing.Point(218, 6);
            this.aButton6.Name = "aButton6";
            this.aButton6.Size = new System.Drawing.Size(145, 118);
            this.aButton6.TabIndex = 5;
            this.aButton6.Text = "현장마감";
            this.aButton6.UseVisualStyleBackColor = false;
            // 
            // aButton7
            // 
            this.aButton7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton7.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton7.Location = new System.Drawing.Point(66, 6);
            this.aButton7.Name = "aButton7";
            this.aButton7.Size = new System.Drawing.Size(145, 118);
            this.aButton7.TabIndex = 6;
            this.aButton7.Text = "작업시작/종료";
            this.aButton7.UseVisualStyleBackColor = false;
            // 
            // aButton8
            // 
            this.aButton8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton8.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton8.Location = new System.Drawing.Point(265, 3);
            this.aButton8.Name = "aButton8";
            this.aButton8.Size = new System.Drawing.Size(126, 118);
            this.aButton8.TabIndex = 13;
            this.aButton8.Text = "작업지시 생성";
            this.aButton8.UseVisualStyleBackColor = false;
            // 
            // aButton9
            // 
            this.aButton9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton9.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton9.Location = new System.Drawing.Point(396, 3);
            this.aButton9.Name = "aButton9";
            this.aButton9.Size = new System.Drawing.Size(126, 118);
            this.aButton9.TabIndex = 12;
            this.aButton9.Text = "작업자 할당";
            this.aButton9.UseVisualStyleBackColor = false;
            // 
            // aButton10
            // 
            this.aButton10.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton10.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton10.Location = new System.Drawing.Point(527, 3);
            this.aButton10.Name = "aButton10";
            this.aButton10.Size = new System.Drawing.Size(126, 118);
            this.aButton10.TabIndex = 11;
            this.aButton10.Text = "적재\r\n실적\r\n등록";
            this.aButton10.UseVisualStyleBackColor = false;
            // 
            // aButton11
            // 
            this.aButton11.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton11.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton11.Location = new System.Drawing.Point(658, 3);
            this.aButton11.Name = "aButton11";
            this.aButton11.Size = new System.Drawing.Size(126, 118);
            this.aButton11.TabIndex = 10;
            this.aButton11.Text = "요입\r\n/요출";
            this.aButton11.UseVisualStyleBackColor = false;
            // 
            // aButton12
            // 
            this.aButton12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton12.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton12.Location = new System.Drawing.Point(789, 3);
            this.aButton12.Name = "aButton12";
            this.aButton12.Size = new System.Drawing.Size(126, 118);
            this.aButton12.TabIndex = 9;
            this.aButton12.Text = "건조대차 비우기";
            this.aButton12.UseVisualStyleBackColor = false;
            // 
            // aButton13
            // 
            this.aButton13.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton13.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton13.Location = new System.Drawing.Point(920, 3);
            this.aButton13.Name = "aButton13";
            this.aButton13.Size = new System.Drawing.Size(126, 118);
            this.aButton13.TabIndex = 8;
            this.aButton13.Text = "공정조건 등록";
            this.aButton13.UseVisualStyleBackColor = false;
            // 
            // aButton14
            // 
            this.aButton14.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton14.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton14.Location = new System.Drawing.Point(1051, 3);
            this.aButton14.Name = "aButton14";
            this.aButton14.Size = new System.Drawing.Size(126, 118);
            this.aButton14.TabIndex = 7;
            this.aButton14.Text = "품질\r\n측정값\r\n등록";
            this.aButton14.UseVisualStyleBackColor = false;
            // 
            // aButton15
            // 
            this.aButton15.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton15.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton15.Location = new System.Drawing.Point(3, 3);
            this.aButton15.Name = "aButton15";
            this.aButton15.Size = new System.Drawing.Size(126, 118);
            this.aButton15.TabIndex = 15;
            this.aButton15.Text = "작업시작/종료";
            this.aButton15.UseVisualStyleBackColor = false;
            // 
            // aButton16
            // 
            this.aButton16.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton16.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton16.Location = new System.Drawing.Point(134, 3);
            this.aButton16.Name = "aButton16";
            this.aButton16.Size = new System.Drawing.Size(126, 118);
            this.aButton16.TabIndex = 14;
            this.aButton16.Text = "현장마감";
            this.aButton16.UseVisualStyleBackColor = false;
            // 
            // aButton17
            // 
            this.aButton17.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton17.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton17.Location = new System.Drawing.Point(6, 3);
            this.aButton17.Name = "aButton17";
            this.aButton17.Size = new System.Drawing.Size(126, 118);
            this.aButton17.TabIndex = 24;
            this.aButton17.Text = "작업시작/종료";
            this.aButton17.UseVisualStyleBackColor = false;
            // 
            // aButton18
            // 
            this.aButton18.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton18.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton18.Location = new System.Drawing.Point(137, 3);
            this.aButton18.Name = "aButton18";
            this.aButton18.Size = new System.Drawing.Size(126, 118);
            this.aButton18.TabIndex = 23;
            this.aButton18.Text = "현장마감";
            this.aButton18.UseVisualStyleBackColor = false;
            // 
            // aButton19
            // 
            this.aButton19.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton19.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton19.Location = new System.Drawing.Point(268, 3);
            this.aButton19.Name = "aButton19";
            this.aButton19.Size = new System.Drawing.Size(126, 118);
            this.aButton19.TabIndex = 22;
            this.aButton19.Text = "작업지시 생성";
            this.aButton19.UseVisualStyleBackColor = false;
            // 
            // aButton20
            // 
            this.aButton20.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton20.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton20.Location = new System.Drawing.Point(399, 3);
            this.aButton20.Name = "aButton20";
            this.aButton20.Size = new System.Drawing.Size(126, 118);
            this.aButton20.TabIndex = 21;
            this.aButton20.Text = "작업자 할당";
            this.aButton20.UseVisualStyleBackColor = false;
            // 
            // aButton21
            // 
            this.aButton21.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton21.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton21.Location = new System.Drawing.Point(530, 3);
            this.aButton21.Name = "aButton21";
            this.aButton21.Size = new System.Drawing.Size(126, 118);
            this.aButton21.TabIndex = 20;
            this.aButton21.Text = "팔레트 생성";
            this.aButton21.UseVisualStyleBackColor = false;
            // 
            // aButton22
            // 
            this.aButton22.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton22.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton22.Location = new System.Drawing.Point(661, 3);
            this.aButton22.Name = "aButton22";
            this.aButton22.Size = new System.Drawing.Size(126, 118);
            this.aButton22.TabIndex = 19;
            this.aButton22.Text = "팔레트 바코드 재발행";
            this.aButton22.UseVisualStyleBackColor = false;
            // 
            // aButton23
            // 
            this.aButton23.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton23.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton23.Location = new System.Drawing.Point(792, 3);
            this.aButton23.Name = "aButton23";
            this.aButton23.Size = new System.Drawing.Size(126, 118);
            this.aButton23.TabIndex = 18;
            this.aButton23.Text = "입고\r\n등록";
            this.aButton23.UseVisualStyleBackColor = false;
            // 
            // aButton24
            // 
            this.aButton24.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton24.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton24.Location = new System.Drawing.Point(923, 3);
            this.aButton24.Name = "aButton24";
            this.aButton24.Size = new System.Drawing.Size(126, 118);
            this.aButton24.TabIndex = 17;
            this.aButton24.Text = "언로딩";
            this.aButton24.UseVisualStyleBackColor = false;
            // 
            // aButton25
            // 
            this.aButton25.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton25.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aButton25.Location = new System.Drawing.Point(1054, 3);
            this.aButton25.Name = "aButton25";
            this.aButton25.Size = new System.Drawing.Size(126, 118);
            this.aButton25.TabIndex = 16;
            this.aButton25.Text = "품질\r\n측정값\r\n등록";
            this.aButton25.UseVisualStyleBackColor = false;
            // 
            // WorkOrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.ClientSize = new System.Drawing.Size(1210, 1019);
            this.Controls.Add(this.aPanel6);
            this.Controls.Add(this.aPanel5);
            this.Controls.Add(this.aPanel4);
            this.Controls.Add(this.aDataGridView1);
            this.Name = "WorkOrderForm";
            this.Controls.SetChildIndex(this.aDataGridView1, 0);
            this.Controls.SetChildIndex(this.aPanel4, 0);
            this.Controls.SetChildIndex(this.aPanel5, 0);
            this.Controls.SetChildIndex(this.aPanel6, 0);
            this.Controls.SetChildIndex(this.aPanel2, 0);
            this.Controls.SetChildIndex(this.aPanel1, 0);
            this.aPanel1.ResumeLayout(false);
            this.aPanel1.PerformLayout();
            this.aPanel2.ResumeLayout(false);
            this.aPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aDataGridView1)).EndInit();
            this.aPanel4.ResumeLayout(false);
            this.aPanel5.ResumeLayout(false);
            this.aPanel6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private CustomControls.ADataGridView aDataGridView1;
        private CustomControls.APanel aPanel4;
        private CustomControls.AButton aButton7;
        private CustomControls.AButton aButton6;
        private CustomControls.AButton aButton5;
        private CustomControls.AButton aButton4;
        private CustomControls.AButton aButton3;
        private CustomControls.AButton aButton2;
        private CustomControls.AButton aButton1;
        private CustomControls.APanel aPanel5;
        private CustomControls.AButton aButton15;
        private CustomControls.AButton aButton16;
        private CustomControls.AButton aButton8;
        private CustomControls.AButton aButton9;
        private CustomControls.AButton aButton10;
        private CustomControls.AButton aButton11;
        private CustomControls.AButton aButton12;
        private CustomControls.AButton aButton13;
        private CustomControls.AButton aButton14;
        private CustomControls.APanel aPanel6;
        private CustomControls.AButton aButton17;
        private CustomControls.AButton aButton18;
        private CustomControls.AButton aButton19;
        private CustomControls.AButton aButton20;
        private CustomControls.AButton aButton21;
        private CustomControls.AButton aButton22;
        private CustomControls.AButton aButton23;
        private CustomControls.AButton aButton24;
        private CustomControls.AButton aButton25;
    }
}
