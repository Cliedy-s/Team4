﻿namespace AxxenClient.Forms
{
    partial class POP_PRD_014
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.aButton2 = new AxxenClient.CustomControls.AButton();
            this.aDataGridView2 = new AxxenClient.CustomControls.ADataGridView();
            this.aPanel5 = new AxxenClient.CustomControls.APanel();
            this.aTextBox_LabeledBigTextBox10 = new AxxenClient.CustomControls.ATextBox_LabeledBigTextBox();
            this.aTextBox_LabeledBigTextBox11 = new AxxenClient.CustomControls.ATextBox_LabeledBigTextBox();
            this.aTextBox_LabeledBigTextBox8 = new AxxenClient.CustomControls.ATextBox_LabeledBigTextBox();
            this.aTextBox_LabeledBigTextBox9 = new AxxenClient.CustomControls.ATextBox_LabeledBigTextBox();
            this.aTextBox_LabeledBigTextBox7 = new AxxenClient.CustomControls.ATextBox_LabeledBigTextBox();
            this.aTextBox_LabeledBigTextBox6 = new AxxenClient.CustomControls.ATextBox_LabeledBigTextBox();
            this.aDataGridView1 = new AxxenClient.CustomControls.ADataGridView();
            this.aTextBox_LabeledBigTextBox1 = new AxxenClient.CustomControls.ATextBox_LabeledBigTextBox();
            this.aButton1 = new AxxenClient.CustomControls.AButton();
            this.aPanel1.SuspendLayout();
            this.aPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aDataGridView2)).BeginInit();
            this.aPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aDataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // aLabel_Header1
            // 
            this.aLabel_Header1.Text = "공정조건 등록";
            // 
            // aButton2
            // 
            this.aButton2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton2.Location = new System.Drawing.Point(626, 473);
            this.aButton2.Name = "aButton2";
            this.aButton2.Size = new System.Drawing.Size(409, 112);
            this.aButton2.TabIndex = 29;
            this.aButton2.Text = "입력";
            this.aButton2.UseVisualStyleBackColor = false;
            // 
            // aDataGridView2
            // 
            this.aDataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.aDataGridView2.Location = new System.Drawing.Point(619, 211);
            this.aDataGridView2.Name = "aDataGridView2";
            this.aDataGridView2.RowTemplate.Height = 23;
            this.aDataGridView2.Size = new System.Drawing.Size(581, 219);
            this.aDataGridView2.TabIndex = 26;
            // 
            // aPanel5
            // 
            this.aPanel5.Controls.Add(this.aTextBox_LabeledBigTextBox10);
            this.aPanel5.Controls.Add(this.aTextBox_LabeledBigTextBox11);
            this.aPanel5.Controls.Add(this.aTextBox_LabeledBigTextBox8);
            this.aPanel5.Controls.Add(this.aTextBox_LabeledBigTextBox9);
            this.aPanel5.Controls.Add(this.aTextBox_LabeledBigTextBox7);
            this.aPanel5.Controls.Add(this.aTextBox_LabeledBigTextBox6);
            this.aPanel5.Location = new System.Drawing.Point(10, 105);
            this.aPanel5.Name = "aPanel5";
            this.aPanel5.Size = new System.Drawing.Size(1191, 100);
            this.aPanel5.TabIndex = 25;
            // 
            // aTextBox_LabeledBigTextBox10
            // 
            this.aTextBox_LabeledBigTextBox10.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aTextBox_LabeledBigTextBox10.LabelText = "단위";
            this.aTextBox_LabeledBigTextBox10.Location = new System.Drawing.Point(802, 54);
            this.aTextBox_LabeledBigTextBox10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aTextBox_LabeledBigTextBox10.Name = "aTextBox_LabeledBigTextBox10";
            this.aTextBox_LabeledBigTextBox10.Size = new System.Drawing.Size(365, 30);
            this.aTextBox_LabeledBigTextBox10.TabIndex = 5;
            this.aTextBox_LabeledBigTextBox10.TextBoxText = "";
            // 
            // aTextBox_LabeledBigTextBox11
            // 
            this.aTextBox_LabeledBigTextBox11.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aTextBox_LabeledBigTextBox11.LabelText = "작업장";
            this.aTextBox_LabeledBigTextBox11.Location = new System.Drawing.Point(802, 16);
            this.aTextBox_LabeledBigTextBox11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aTextBox_LabeledBigTextBox11.Name = "aTextBox_LabeledBigTextBox11";
            this.aTextBox_LabeledBigTextBox11.Size = new System.Drawing.Size(365, 30);
            this.aTextBox_LabeledBigTextBox11.TabIndex = 4;
            this.aTextBox_LabeledBigTextBox11.TextBoxText = "";
            // 
            // aTextBox_LabeledBigTextBox8
            // 
            this.aTextBox_LabeledBigTextBox8.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aTextBox_LabeledBigTextBox8.LabelText = "실적수량";
            this.aTextBox_LabeledBigTextBox8.Location = new System.Drawing.Point(413, 54);
            this.aTextBox_LabeledBigTextBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aTextBox_LabeledBigTextBox8.Name = "aTextBox_LabeledBigTextBox8";
            this.aTextBox_LabeledBigTextBox8.Size = new System.Drawing.Size(365, 30);
            this.aTextBox_LabeledBigTextBox8.TabIndex = 3;
            this.aTextBox_LabeledBigTextBox8.TextBoxText = "";
            // 
            // aTextBox_LabeledBigTextBox9
            // 
            this.aTextBox_LabeledBigTextBox9.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aTextBox_LabeledBigTextBox9.LabelText = "품목";
            this.aTextBox_LabeledBigTextBox9.Location = new System.Drawing.Point(413, 16);
            this.aTextBox_LabeledBigTextBox9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aTextBox_LabeledBigTextBox9.Name = "aTextBox_LabeledBigTextBox9";
            this.aTextBox_LabeledBigTextBox9.Size = new System.Drawing.Size(365, 30);
            this.aTextBox_LabeledBigTextBox9.TabIndex = 2;
            this.aTextBox_LabeledBigTextBox9.TextBoxText = "";
            // 
            // aTextBox_LabeledBigTextBox7
            // 
            this.aTextBox_LabeledBigTextBox7.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aTextBox_LabeledBigTextBox7.LabelText = "작업지시일";
            this.aTextBox_LabeledBigTextBox7.Location = new System.Drawing.Point(16, 54);
            this.aTextBox_LabeledBigTextBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aTextBox_LabeledBigTextBox7.Name = "aTextBox_LabeledBigTextBox7";
            this.aTextBox_LabeledBigTextBox7.Size = new System.Drawing.Size(365, 30);
            this.aTextBox_LabeledBigTextBox7.TabIndex = 1;
            this.aTextBox_LabeledBigTextBox7.TextBoxText = "";
            // 
            // aTextBox_LabeledBigTextBox6
            // 
            this.aTextBox_LabeledBigTextBox6.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aTextBox_LabeledBigTextBox6.LabelText = "작업지시번호";
            this.aTextBox_LabeledBigTextBox6.Location = new System.Drawing.Point(16, 16);
            this.aTextBox_LabeledBigTextBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aTextBox_LabeledBigTextBox6.Name = "aTextBox_LabeledBigTextBox6";
            this.aTextBox_LabeledBigTextBox6.Size = new System.Drawing.Size(365, 30);
            this.aTextBox_LabeledBigTextBox6.TabIndex = 0;
            this.aTextBox_LabeledBigTextBox6.TextBoxText = "";
            // 
            // aDataGridView1
            // 
            this.aDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.aDataGridView1.Location = new System.Drawing.Point(10, 211);
            this.aDataGridView1.Name = "aDataGridView1";
            this.aDataGridView1.RowTemplate.Height = 23;
            this.aDataGridView1.Size = new System.Drawing.Size(610, 374);
            this.aDataGridView1.TabIndex = 24;
            // 
            // aTextBox_LabeledBigTextBox1
            // 
            this.aTextBox_LabeledBigTextBox1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aTextBox_LabeledBigTextBox1.LabelText = "측정값";
            this.aTextBox_LabeledBigTextBox1.Location = new System.Drawing.Point(626, 437);
            this.aTextBox_LabeledBigTextBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aTextBox_LabeledBigTextBox1.Name = "aTextBox_LabeledBigTextBox1";
            this.aTextBox_LabeledBigTextBox1.Size = new System.Drawing.Size(365, 30);
            this.aTextBox_LabeledBigTextBox1.TabIndex = 30;
            this.aTextBox_LabeledBigTextBox1.TextBoxText = "";
            // 
            // aButton1
            // 
            this.aButton1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton1.Location = new System.Drawing.Point(1042, 473);
            this.aButton1.Name = "aButton1";
            this.aButton1.Size = new System.Drawing.Size(160, 112);
            this.aButton1.TabIndex = 31;
            this.aButton1.Text = "삭제";
            this.aButton1.UseVisualStyleBackColor = false;
            // 
            // POP_PRD_014
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.ClientSize = new System.Drawing.Size(1210, 629);
            this.Controls.Add(this.aButton1);
            this.Controls.Add(this.aTextBox_LabeledBigTextBox1);
            this.Controls.Add(this.aButton2);
            this.Controls.Add(this.aDataGridView2);
            this.Controls.Add(this.aPanel5);
            this.Controls.Add(this.aDataGridView1);
            this.Name = "POP_PRD_014";
            this.Controls.SetChildIndex(this.aPanel2, 0);
            this.Controls.SetChildIndex(this.aPanel1, 0);
            this.Controls.SetChildIndex(this.aDataGridView1, 0);
            this.Controls.SetChildIndex(this.aPanel5, 0);
            this.Controls.SetChildIndex(this.aDataGridView2, 0);
            this.Controls.SetChildIndex(this.aButton2, 0);
            this.Controls.SetChildIndex(this.aTextBox_LabeledBigTextBox1, 0);
            this.Controls.SetChildIndex(this.aButton1, 0);
            this.aPanel1.ResumeLayout(false);
            this.aPanel1.PerformLayout();
            this.aPanel2.ResumeLayout(false);
            this.aPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aDataGridView2)).EndInit();
            this.aPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.aDataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private CustomControls.AButton aButton2;
        private CustomControls.ADataGridView aDataGridView2;
        private CustomControls.APanel aPanel5;
        private CustomControls.ATextBox_LabeledBigTextBox aTextBox_LabeledBigTextBox10;
        private CustomControls.ATextBox_LabeledBigTextBox aTextBox_LabeledBigTextBox11;
        private CustomControls.ATextBox_LabeledBigTextBox aTextBox_LabeledBigTextBox8;
        private CustomControls.ATextBox_LabeledBigTextBox aTextBox_LabeledBigTextBox9;
        private CustomControls.ATextBox_LabeledBigTextBox aTextBox_LabeledBigTextBox7;
        private CustomControls.ATextBox_LabeledBigTextBox aTextBox_LabeledBigTextBox6;
        private CustomControls.ADataGridView aDataGridView1;
        private CustomControls.ATextBox_LabeledBigTextBox aTextBox_LabeledBigTextBox1;
        private CustomControls.AButton aButton1;
    }
}
