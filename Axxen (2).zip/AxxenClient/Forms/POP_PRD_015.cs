﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AxxenClient.Forms
{
    public partial class POP_PRD_015 : AxxenClient.Templets.ClientBaseForm
    {
        public POP_PRD_015()
        {
            InitializeComponent();
        }
    }
}
