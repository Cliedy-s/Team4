﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Axxen
{
    public partial class PRM_PRF_002 : Axxen.GridGridForm
    {
        public PRM_PRF_002()
        {
            InitializeComponent();
        }
    }
}
