﻿namespace Axxen.sangyoung
{
    partial class PPS_MLD_001
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.aTextBox_Labeled2 = new Axxen.CustomControls.ATextBox_Labeled();
            this.aTextBox_Labeled1 = new Axxen.CustomControls.ATextBox_Labeled();
            this.aComboBox1 = new Axxen.CustomControls.AComboBox();
            this.aLabel1 = new Axxen.CustomControls.ALabel();
            this.aTextBox_Labeled3 = new Axxen.CustomControls.ATextBox_Labeled();
            this.aTextBox_Labeled4 = new Axxen.CustomControls.ATextBox_Labeled();
            this.aTextBox_Labeled5 = new Axxen.CustomControls.ATextBox_Labeled();
            this.aLabel2 = new Axxen.CustomControls.ALabel();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.aLabel3 = new Axxen.CustomControls.ALabel();
            this.aLabel4 = new Axxen.CustomControls.ALabel();
            this.aLabel5 = new Axxen.CustomControls.ALabel();
            this.aDateTimePicker1 = new Axxen.CustomControls.ADateTimePicker();
            this.aDateTimePicker2 = new Axxen.CustomControls.ADateTimePicker();
            this.aLabel6 = new Axxen.CustomControls.ALabel();
            this.aTextBox1 = new Axxen.CustomControls.ATextBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.aPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aSplitContainer1)).BeginInit();
            this.aSplitContainer1.Panel2.SuspendLayout();
            this.aSplitContainer1.SuspendLayout();
            this.aPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // aPanel2
            // 
            this.aPanel2.Controls.Add(this.aTextBox_Labeled2);
            this.aPanel2.Controls.Add(this.aTextBox_Labeled1);
            this.aPanel2.Controls.Add(this.aLabel1);
            this.aPanel2.Controls.Add(this.aComboBox1);
            // 
            // aSplitContainer1
            // 
            // 
            // aPanel1
            // 
            this.aPanel1.Controls.Add(this.radioButton2);
            this.aPanel1.Controls.Add(this.radioButton1);
            this.aPanel1.Controls.Add(this.aTextBox1);
            this.aPanel1.Controls.Add(this.aLabel6);
            this.aPanel1.Controls.Add(this.aDateTimePicker2);
            this.aPanel1.Controls.Add(this.aDateTimePicker1);
            this.aPanel1.Controls.Add(this.aLabel5);
            this.aPanel1.Controls.Add(this.aLabel4);
            this.aPanel1.Controls.Add(this.aLabel3);
            this.aPanel1.Controls.Add(this.numericUpDown1);
            this.aPanel1.Controls.Add(this.aLabel2);
            this.aPanel1.Controls.Add(this.aTextBox_Labeled5);
            this.aPanel1.Controls.Add(this.aTextBox_Labeled4);
            this.aPanel1.Controls.Add(this.aTextBox_Labeled3);
            this.aPanel1.Controls.SetChildIndex(this.aHeaderBox2, 0);
            this.aPanel1.Controls.SetChildIndex(this.aTextBox_Labeled3, 0);
            this.aPanel1.Controls.SetChildIndex(this.aTextBox_Labeled4, 0);
            this.aPanel1.Controls.SetChildIndex(this.aTextBox_Labeled5, 0);
            this.aPanel1.Controls.SetChildIndex(this.aLabel2, 0);
            this.aPanel1.Controls.SetChildIndex(this.numericUpDown1, 0);
            this.aPanel1.Controls.SetChildIndex(this.aLabel3, 0);
            this.aPanel1.Controls.SetChildIndex(this.aLabel4, 0);
            this.aPanel1.Controls.SetChildIndex(this.aLabel5, 0);
            this.aPanel1.Controls.SetChildIndex(this.aDateTimePicker1, 0);
            this.aPanel1.Controls.SetChildIndex(this.aDateTimePicker2, 0);
            this.aPanel1.Controls.SetChildIndex(this.aLabel6, 0);
            this.aPanel1.Controls.SetChildIndex(this.aTextBox1, 0);
            this.aPanel1.Controls.SetChildIndex(this.radioButton1, 0);
            this.aPanel1.Controls.SetChildIndex(this.radioButton2, 0);
            // 
            // aHeaderBox1
            // 
            this.aHeaderBox1.HeaderBoxText = "조회내역";
            // 
            // aHeaderBox2
            // 
            this.aHeaderBox2.HeaderBoxText = "입력정보";
            // 
            // aTextBox_Labeled2
            // 
            this.aTextBox_Labeled2.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aTextBox_Labeled2.FontSize = 9F;
            this.aTextBox_Labeled2.LabelText = "금형 명";
            this.aTextBox_Labeled2.Location = new System.Drawing.Point(354, 32);
            this.aTextBox_Labeled2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.aTextBox_Labeled2.Name = "aTextBox_Labeled2";
            this.aTextBox_Labeled2.Size = new System.Drawing.Size(205, 23);
            this.aTextBox_Labeled2.TabIndex = 18;
            this.aTextBox_Labeled2.TextBoxText = "";
            // 
            // aTextBox_Labeled1
            // 
            this.aTextBox_Labeled1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aTextBox_Labeled1.FontSize = 9F;
            this.aTextBox_Labeled1.LabelText = "금형 코드";
            this.aTextBox_Labeled1.Location = new System.Drawing.Point(27, 32);
            this.aTextBox_Labeled1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aTextBox_Labeled1.Name = "aTextBox_Labeled1";
            this.aTextBox_Labeled1.Size = new System.Drawing.Size(212, 23);
            this.aTextBox_Labeled1.TabIndex = 17;
            this.aTextBox_Labeled1.TextBoxText = "";
            // 
            // aComboBox1
            // 
            this.aComboBox1.FormattingEnabled = true;
            this.aComboBox1.Location = new System.Drawing.Point(698, 32);
            this.aComboBox1.Name = "aComboBox1";
            this.aComboBox1.Size = new System.Drawing.Size(106, 23);
            this.aComboBox1.TabIndex = 16;
            // 
            // aLabel1
            // 
            this.aLabel1.AutoSize = true;
            this.aLabel1.Location = new System.Drawing.Point(649, 36);
            this.aLabel1.Name = "aLabel1";
            this.aLabel1.Size = new System.Drawing.Size(43, 15);
            this.aLabel1.TabIndex = 15;
            this.aLabel1.Text = "생산월";
            // 
            // aTextBox_Labeled3
            // 
            this.aTextBox_Labeled3.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aTextBox_Labeled3.FontSize = 9F;
            this.aTextBox_Labeled3.LabelText = "금형코드";
            this.aTextBox_Labeled3.Location = new System.Drawing.Point(257, 12);
            this.aTextBox_Labeled3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aTextBox_Labeled3.Name = "aTextBox_Labeled3";
            this.aTextBox_Labeled3.Size = new System.Drawing.Size(212, 23);
            this.aTextBox_Labeled3.TabIndex = 18;
            this.aTextBox_Labeled3.TextBoxText = "";
            // 
            // aTextBox_Labeled4
            // 
            this.aTextBox_Labeled4.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aTextBox_Labeled4.FontSize = 9F;
            this.aTextBox_Labeled4.LabelText = "금형그룹";
            this.aTextBox_Labeled4.Location = new System.Drawing.Point(257, 74);
            this.aTextBox_Labeled4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aTextBox_Labeled4.Name = "aTextBox_Labeled4";
            this.aTextBox_Labeled4.Size = new System.Drawing.Size(212, 23);
            this.aTextBox_Labeled4.TabIndex = 19;
            this.aTextBox_Labeled4.TextBoxText = "";
            // 
            // aTextBox_Labeled5
            // 
            this.aTextBox_Labeled5.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aTextBox_Labeled5.FontSize = 9F;
            this.aTextBox_Labeled5.LabelText = "금형명";
            this.aTextBox_Labeled5.Location = new System.Drawing.Point(257, 43);
            this.aTextBox_Labeled5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aTextBox_Labeled5.Name = "aTextBox_Labeled5";
            this.aTextBox_Labeled5.Size = new System.Drawing.Size(212, 23);
            this.aTextBox_Labeled5.TabIndex = 20;
            this.aTextBox_Labeled5.TextBoxText = "";
            // 
            // aLabel2
            // 
            this.aLabel2.AutoSize = true;
            this.aLabel2.Location = new System.Drawing.Point(527, 18);
            this.aLabel2.Name = "aLabel2";
            this.aLabel2.Size = new System.Drawing.Size(55, 15);
            this.aLabel2.TabIndex = 22;
            this.aLabel2.Text = "보장타수";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(611, 12);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(104, 23);
            this.numericUpDown1.TabIndex = 23;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // aLabel3
            // 
            this.aLabel3.AutoSize = true;
            this.aLabel3.Location = new System.Drawing.Point(527, 49);
            this.aLabel3.Name = "aLabel3";
            this.aLabel3.Size = new System.Drawing.Size(55, 15);
            this.aLabel3.TabIndex = 24;
            this.aLabel3.Text = "입고일자";
            // 
            // aLabel4
            // 
            this.aLabel4.AutoSize = true;
            this.aLabel4.Location = new System.Drawing.Point(527, 80);
            this.aLabel4.Name = "aLabel4";
            this.aLabel4.Size = new System.Drawing.Size(79, 15);
            this.aLabel4.TabIndex = 25;
            this.aLabel4.Text = "최종장착일시";
            // 
            // aLabel5
            // 
            this.aLabel5.AutoSize = true;
            this.aLabel5.Location = new System.Drawing.Point(801, 20);
            this.aLabel5.Name = "aLabel5";
            this.aLabel5.Size = new System.Drawing.Size(55, 15);
            this.aLabel5.TabIndex = 26;
            this.aLabel5.Text = "사용유무";
            // 
            // aDateTimePicker1
            // 
            this.aDateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.aDateTimePicker1.Location = new System.Drawing.Point(611, 43);
            this.aDateTimePicker1.Name = "aDateTimePicker1";
            this.aDateTimePicker1.Size = new System.Drawing.Size(134, 23);
            this.aDateTimePicker1.TabIndex = 28;
            // 
            // aDateTimePicker2
            // 
            this.aDateTimePicker2.CustomFormat = "yyyy-MM-dd hh-mm";
            this.aDateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.aDateTimePicker2.Location = new System.Drawing.Point(612, 76);
            this.aDateTimePicker2.Name = "aDateTimePicker2";
            this.aDateTimePicker2.Size = new System.Drawing.Size(133, 23);
            this.aDateTimePicker2.TabIndex = 28;
            // 
            // aLabel6
            // 
            this.aLabel6.AutoSize = true;
            this.aLabel6.Location = new System.Drawing.Point(802, 52);
            this.aLabel6.Name = "aLabel6";
            this.aLabel6.Size = new System.Drawing.Size(31, 15);
            this.aLabel6.TabIndex = 29;
            this.aLabel6.Text = "비고";
            // 
            // aTextBox1
            // 
            this.aTextBox1.BackColor = System.Drawing.Color.White;
            this.aTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aTextBox1.errorp = null;
            this.aTextBox1.Location = new System.Drawing.Point(805, 70);
            this.aTextBox1.Name = "aTextBox1";
            this.aTextBox1.Size = new System.Drawing.Size(263, 23);
            this.aTextBox1.TabIndex = 30;
            this.aTextBox1.txtType = Axxen.CustomControls.type.Normal;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(874, 18);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(32, 19);
            this.radioButton1.TabIndex = 31;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Y";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(912, 18);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(34, 19);
            this.radioButton2.TabIndex = 31;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "N";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // PPS_MLD_001
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.ClientSize = new System.Drawing.Size(1148, 700);
            this.Name = "PPS_MLD_001";
            this.aPanel2.ResumeLayout(false);
            this.aPanel2.PerformLayout();
            this.aSplitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.aSplitContainer1)).EndInit();
            this.aSplitContainer1.ResumeLayout(false);
            this.aPanel1.ResumeLayout(false);
            this.aPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private CustomControls.ATextBox_Labeled aTextBox_Labeled2;
        private CustomControls.ATextBox_Labeled aTextBox_Labeled1;
        private CustomControls.AComboBox aComboBox1;
        private CustomControls.ALabel aLabel1;
        private CustomControls.ALabel aLabel4;
        private CustomControls.ALabel aLabel3;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private CustomControls.ALabel aLabel2;
        private CustomControls.ATextBox_Labeled aTextBox_Labeled5;
        private CustomControls.ATextBox_Labeled aTextBox_Labeled4;
        private CustomControls.ATextBox_Labeled aTextBox_Labeled3;
        private CustomControls.ATextBox aTextBox1;
        private CustomControls.ALabel aLabel6;
        private CustomControls.ADateTimePicker aDateTimePicker2;
        private CustomControls.ADateTimePicker aDateTimePicker1;
        private CustomControls.ALabel aLabel5;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
    }
}
