﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Axxen.sangyoung
{
    public partial class PPS_MLD_002 : Axxen.GridForm
    {
        public PPS_MLD_002()
        {
            InitializeComponent();
        }
    }
}
