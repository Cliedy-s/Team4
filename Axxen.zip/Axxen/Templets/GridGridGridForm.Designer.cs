﻿namespace Axxen
{
    partial class GridGridGridForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.aSplitContainer1 = new Axxen.CustomControls.ASplitContainer();
            this.aDataGridView3 = new Axxen.CustomControls.ADataGridView();
            this.aHeaderBox1 = new Axxen.CustomControls.AHeaderBox();
            this.aHeaderBox2 = new Axxen.CustomControls.AHeaderBox();
            this.aGroupBox1 = new Axxen.CustomControls.AGroupBox();
            this.aDataGridView1 = new Axxen.CustomControls.ADataGridView();
            this.aGroupBox2 = new Axxen.CustomControls.AGroupBox();
            this.aDataGridView2 = new Axxen.CustomControls.ADataGridView();
            this.aPanel1 = new Axxen.CustomControls.APanel();
            ((System.ComponentModel.ISupportInitialize)(this.aSplitContainer1)).BeginInit();
            this.aSplitContainer1.Panel1.SuspendLayout();
            this.aSplitContainer1.Panel2.SuspendLayout();
            this.aSplitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aDataGridView3)).BeginInit();
            this.aGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aDataGridView1)).BeginInit();
            this.aGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aDataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // aSplitContainer1
            // 
            this.aSplitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.aSplitContainer1.Location = new System.Drawing.Point(12, 97);
            this.aSplitContainer1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aSplitContainer1.Name = "aSplitContainer1";
            // 
            // aSplitContainer1.Panel1
            // 
            this.aSplitContainer1.Panel1.Controls.Add(this.aDataGridView3);
            this.aSplitContainer1.Panel1.Controls.Add(this.aHeaderBox1);
            // 
            // aSplitContainer1.Panel2
            // 
            this.aSplitContainer1.Panel2.Controls.Add(this.aHeaderBox2);
            this.aSplitContainer1.Panel2.Controls.Add(this.aGroupBox1);
            this.aSplitContainer1.Panel2.Controls.Add(this.aGroupBox2);
            this.aSplitContainer1.Size = new System.Drawing.Size(1125, 588);
            this.aSplitContainer1.SplitterDistance = 261;
            this.aSplitContainer1.SplitterWidth = 1;
            this.aSplitContainer1.TabIndex = 9;
            // 
            // aDataGridView3
            // 
            this.aDataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.aDataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.aDataGridView3.Location = new System.Drawing.Point(0, 29);
            this.aDataGridView3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aDataGridView3.Name = "aDataGridView3";
            this.aDataGridView3.RowHeadersWidth = 51;
            this.aDataGridView3.RowTemplate.Height = 23;
            this.aDataGridView3.Size = new System.Drawing.Size(259, 559);
            this.aDataGridView3.TabIndex = 0;
            // 
            // aHeaderBox1
            // 
            this.aHeaderBox1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.aHeaderBox1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aHeaderBox1.HeaderBoxText = "HeaderText";
            this.aHeaderBox1.Location = new System.Drawing.Point(1, 0);
            this.aHeaderBox1.Name = "aHeaderBox1";
            this.aHeaderBox1.Size = new System.Drawing.Size(192, 30);
            this.aHeaderBox1.TabIndex = 11;
            // 
            // aHeaderBox2
            // 
            this.aHeaderBox2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.aHeaderBox2.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aHeaderBox2.HeaderBoxText = "HeaderText";
            this.aHeaderBox2.Location = new System.Drawing.Point(2, 2);
            this.aHeaderBox2.Name = "aHeaderBox2";
            this.aHeaderBox2.Size = new System.Drawing.Size(192, 30);
            this.aHeaderBox2.TabIndex = 12;
            // 
            // aGroupBox1
            // 
            this.aGroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.aGroupBox1.Controls.Add(this.aDataGridView1);
            this.aGroupBox1.Location = new System.Drawing.Point(3, 29);
            this.aGroupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aGroupBox1.Name = "aGroupBox1";
            this.aGroupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aGroupBox1.Size = new System.Drawing.Size(203, 560);
            this.aGroupBox1.TabIndex = 0;
            this.aGroupBox1.TabStop = false;
            this.aGroupBox1.Text = "aGroupBox1";
            // 
            // aDataGridView1
            // 
            this.aDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.aDataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.aDataGridView1.Location = new System.Drawing.Point(3, 20);
            this.aDataGridView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aDataGridView1.Name = "aDataGridView1";
            this.aDataGridView1.RowHeadersWidth = 51;
            this.aDataGridView1.RowTemplate.Height = 23;
            this.aDataGridView1.Size = new System.Drawing.Size(197, 536);
            this.aDataGridView1.TabIndex = 0;
            // 
            // aGroupBox2
            // 
            this.aGroupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.aGroupBox2.Controls.Add(this.aDataGridView2);
            this.aGroupBox2.Location = new System.Drawing.Point(209, 29);
            this.aGroupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aGroupBox2.Name = "aGroupBox2";
            this.aGroupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aGroupBox2.Size = new System.Drawing.Size(653, 560);
            this.aGroupBox2.TabIndex = 1;
            this.aGroupBox2.TabStop = false;
            this.aGroupBox2.Text = "aGroupBox2";
            // 
            // aDataGridView2
            // 
            this.aDataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.aDataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.aDataGridView2.Location = new System.Drawing.Point(3, 60);
            this.aDataGridView2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aDataGridView2.Name = "aDataGridView2";
            this.aDataGridView2.RowHeadersWidth = 51;
            this.aDataGridView2.RowTemplate.Height = 23;
            this.aDataGridView2.Size = new System.Drawing.Size(647, 496);
            this.aDataGridView2.TabIndex = 0;
            // 
            // aPanel1
            // 
            this.aPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.aPanel1.Location = new System.Drawing.Point(12, 15);
            this.aPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.aPanel1.Name = "aPanel1";
            this.aPanel1.Size = new System.Drawing.Size(1125, 74);
            this.aPanel1.TabIndex = 8;
            // 
            // GridGridGridForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1148, 700);
            this.Controls.Add(this.aSplitContainer1);
            this.Controls.Add(this.aPanel1);
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Name = "GridGridGridForm";
            this.Text = "GridGridGridForm";
            this.aSplitContainer1.Panel1.ResumeLayout(false);
            this.aSplitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.aSplitContainer1)).EndInit();
            this.aSplitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.aDataGridView3)).EndInit();
            this.aGroupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.aDataGridView1)).EndInit();
            this.aGroupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.aDataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        protected CustomControls.ASplitContainer aSplitContainer1;
        protected CustomControls.APanel aPanel1;
        protected CustomControls.AGroupBox aGroupBox1;
        protected CustomControls.AGroupBox aGroupBox2;
        protected CustomControls.ADataGridView aDataGridView2;
        protected CustomControls.ADataGridView aDataGridView3;
        protected CustomControls.ADataGridView aDataGridView1;
        protected CustomControls.AHeaderBox aHeaderBox1;
        protected CustomControls.AHeaderBox aHeaderBox2;
    }
}