﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Axxen
{
    public partial class QAM_SQC_001 : Form
    {
        public QAM_SQC_001()
        {
            InitializeComponent();
        }
    }
}
