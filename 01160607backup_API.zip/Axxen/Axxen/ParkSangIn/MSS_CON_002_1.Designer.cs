﻿namespace Axxen
{
    partial class MSS_CON_002_1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MSS_CON_002_1));
            this.aLabel5 = new Axxen.CustomControls.ALabel();
            this.aLabel2 = new Axxen.CustomControls.ALabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.aPanel1 = new Axxen.CustomControls.APanel();
            this.aPanel2 = new Axxen.CustomControls.APanel();
            this.aLabel1 = new Axxen.CustomControls.ALabel();
            this.aPanel3 = new Axxen.CustomControls.APanel();
            this.btnScreenSearch = new Axxen.CustomControls.AButton();
            this.txtSearch = new Axxen.CustomControls.ATextBox();
            this.rdoScreenCode = new System.Windows.Forms.RadioButton();
            this.rdoScreenName = new System.Windows.Forms.RadioButton();
            this.dgvNotUseScreen = new Axxen.CustomControls.ADataGridView();
            this.aPanel4 = new Axxen.CustomControls.APanel();
            this.aButton3 = new Axxen.CustomControls.AButton();
            this.btnSave = new Axxen.CustomControls.AButton();
            this.aPanel5 = new Axxen.CustomControls.APanel();
            this.aPanel6 = new Axxen.CustomControls.APanel();
            this.aLabel6 = new Axxen.CustomControls.ALabel();
            this.aLabel4 = new Axxen.CustomControls.ALabel();
            this.btngroub = new Axxen.CustomControls.AButton();
            this.lblGroup = new Axxen.CustomControls.ATextBox();
            this.cbbGroup = new Axxen.CustomControls.AComboBox();
            this.aPanel7 = new Axxen.CustomControls.APanel();
            this.aLabel3 = new Axxen.CustomControls.ALabel();
            this.btnInsert = new Axxen.CustomControls.AButton();
            this.btnRemove = new Axxen.CustomControls.AButton();
            this.aLabel7 = new Axxen.CustomControls.ALabel();
            this.aLabel8 = new Axxen.CustomControls.ALabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.aLabel9 = new Axxen.CustomControls.ALabel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.aLabel10 = new Axxen.CustomControls.ALabel();
            this.aPanel8 = new Axxen.CustomControls.APanel();
            this.dgvUseScreen = new Axxen.CustomControls.ADataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.aPanel1.SuspendLayout();
            this.aPanel2.SuspendLayout();
            this.aPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNotUseScreen)).BeginInit();
            this.aPanel4.SuspendLayout();
            this.aPanel5.SuspendLayout();
            this.aPanel6.SuspendLayout();
            this.aPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.aPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUseScreen)).BeginInit();
            this.SuspendLayout();
            // 
            // aLabel5
            // 
            this.aLabel5.AutoSize = true;
            this.aLabel5.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aLabel5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.aLabel5.Location = new System.Drawing.Point(47, 9);
            this.aLabel5.Name = "aLabel5";
            this.aLabel5.Size = new System.Drawing.Size(80, 21);
            this.aLabel5.TabIndex = 17;
            this.aLabel5.Text = "그룹 추가";
            // 
            // aLabel2
            // 
            this.aLabel2.AutoSize = true;
            this.aLabel2.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aLabel2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.aLabel2.Location = new System.Drawing.Point(43, 10);
            this.aLabel2.Name = "aLabel2";
            this.aLabel2.Size = new System.Drawing.Size(0, 21);
            this.aLabel2.TabIndex = 15;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(18, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(23, 22);
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            // 
            // aPanel1
            // 
            this.aPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.aPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aPanel1.Controls.Add(this.aLabel5);
            this.aPanel1.Controls.Add(this.aLabel2);
            this.aPanel1.Controls.Add(this.pictureBox2);
            this.aPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.aPanel1.Location = new System.Drawing.Point(0, 0);
            this.aPanel1.Name = "aPanel1";
            this.aPanel1.Size = new System.Drawing.Size(1297, 41);
            this.aPanel1.TabIndex = 18;
            // 
            // aPanel2
            // 
            this.aPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.aPanel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aPanel2.Controls.Add(this.aLabel1);
            this.aPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.aPanel2.Location = new System.Drawing.Point(0, 0);
            this.aPanel2.Name = "aPanel2";
            this.aPanel2.Size = new System.Drawing.Size(128, 40);
            this.aPanel2.TabIndex = 19;
            // 
            // aLabel1
            // 
            this.aLabel1.AutoSize = true;
            this.aLabel1.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aLabel1.Location = new System.Drawing.Point(74, 7);
            this.aLabel1.Name = "aLabel1";
            this.aLabel1.Size = new System.Drawing.Size(42, 21);
            this.aLabel1.TabIndex = 23;
            this.aLabel1.Text = "화면";
            // 
            // aPanel3
            // 
            this.aPanel3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.aPanel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aPanel3.Controls.Add(this.btnScreenSearch);
            this.aPanel3.Controls.Add(this.txtSearch);
            this.aPanel3.Controls.Add(this.rdoScreenCode);
            this.aPanel3.Controls.Add(this.rdoScreenName);
            this.aPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.aPanel3.Location = new System.Drawing.Point(128, 0);
            this.aPanel3.Name = "aPanel3";
            this.aPanel3.Size = new System.Drawing.Size(1169, 40);
            this.aPanel3.TabIndex = 20;
            // 
            // btnScreenSearch
            // 
            this.btnScreenSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(239)))), ((int)(((byte)(245)))));
            this.btnScreenSearch.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnScreenSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnScreenSearch.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnScreenSearch.Location = new System.Drawing.Point(479, 6);
            this.btnScreenSearch.Name = "btnScreenSearch";
            this.btnScreenSearch.Size = new System.Drawing.Size(75, 23);
            this.btnScreenSearch.TabIndex = 3;
            this.btnScreenSearch.Text = "조회";
            this.btnScreenSearch.UseVisualStyleBackColor = false;
            this.btnScreenSearch.Click += new System.EventHandler(this.BtnScreenSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearch.errorp = null;
            this.txtSearch.Location = new System.Drawing.Point(148, 6);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(310, 23);
            this.txtSearch.TabIndex = 2;
            this.txtSearch.txtType = Axxen.CustomControls.type.Normal;
            // 
            // rdoScreenCode
            // 
            this.rdoScreenCode.AutoSize = true;
            this.rdoScreenCode.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rdoScreenCode.Location = new System.Drawing.Point(73, 7);
            this.rdoScreenCode.Name = "rdoScreenCode";
            this.rdoScreenCode.Size = new System.Drawing.Size(78, 21);
            this.rdoScreenCode.TabIndex = 1;
            this.rdoScreenCode.TabStop = true;
            this.rdoScreenCode.Tag = "2";
            this.rdoScreenCode.Text = "화면코드";
            this.rdoScreenCode.UseVisualStyleBackColor = true;
            // 
            // rdoScreenName
            // 
            this.rdoScreenName.AutoSize = true;
            this.rdoScreenName.Checked = true;
            this.rdoScreenName.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rdoScreenName.Location = new System.Drawing.Point(6, 7);
            this.rdoScreenName.Name = "rdoScreenName";
            this.rdoScreenName.Size = new System.Drawing.Size(65, 21);
            this.rdoScreenName.TabIndex = 0;
            this.rdoScreenName.TabStop = true;
            this.rdoScreenName.Tag = "1";
            this.rdoScreenName.Text = "화면명";
            this.rdoScreenName.UseVisualStyleBackColor = true;
            // 
            // dgvNotUseScreen
            // 
            this.dgvNotUseScreen.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvNotUseScreen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvNotUseScreen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNotUseScreen.Location = new System.Drawing.Point(2, 147);
            this.dgvNotUseScreen.Name = "dgvNotUseScreen";
            this.dgvNotUseScreen.RowTemplate.Height = 23;
            this.dgvNotUseScreen.Size = new System.Drawing.Size(419, 590);
            this.dgvNotUseScreen.TabIndex = 21;
            this.dgvNotUseScreen.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DgvNotUseScreen_CellMouseDoubleClick);
            // 
            // aPanel4
            // 
            this.aPanel4.BackColor = System.Drawing.Color.PowderBlue;
            this.aPanel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aPanel4.Controls.Add(this.aButton3);
            this.aPanel4.Controls.Add(this.btnSave);
            this.aPanel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.aPanel4.Location = new System.Drawing.Point(0, 739);
            this.aPanel4.Name = "aPanel4";
            this.aPanel4.Size = new System.Drawing.Size(1297, 41);
            this.aPanel4.TabIndex = 22;
            // 
            // aButton3
            // 
            this.aButton3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.aButton3.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.aButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aButton3.Location = new System.Drawing.Point(1209, 8);
            this.aButton3.Name = "aButton3";
            this.aButton3.Size = new System.Drawing.Size(75, 23);
            this.aButton3.TabIndex = 1;
            this.aButton3.Text = "취소";
            this.aButton3.UseVisualStyleBackColor = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnSave.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Location = new System.Drawing.Point(1119, 8);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 0;
            this.btnSave.Text = "저장";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // aPanel5
            // 
            this.aPanel5.Controls.Add(this.aPanel6);
            this.aPanel5.Controls.Add(this.aPanel7);
            this.aPanel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.aPanel5.Location = new System.Drawing.Point(0, 41);
            this.aPanel5.Name = "aPanel5";
            this.aPanel5.Size = new System.Drawing.Size(1297, 40);
            this.aPanel5.TabIndex = 23;
            // 
            // aPanel6
            // 
            this.aPanel6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.aPanel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aPanel6.Controls.Add(this.aLabel6);
            this.aPanel6.Controls.Add(this.aLabel4);
            this.aPanel6.Controls.Add(this.btngroub);
            this.aPanel6.Controls.Add(this.lblGroup);
            this.aPanel6.Controls.Add(this.cbbGroup);
            this.aPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.aPanel6.Location = new System.Drawing.Point(128, 0);
            this.aPanel6.Name = "aPanel6";
            this.aPanel6.Size = new System.Drawing.Size(1169, 40);
            this.aPanel6.TabIndex = 25;
            // 
            // aLabel6
            // 
            this.aLabel6.AutoSize = true;
            this.aLabel6.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aLabel6.Location = new System.Drawing.Point(244, 11);
            this.aLabel6.Name = "aLabel6";
            this.aLabel6.Size = new System.Drawing.Size(60, 17);
            this.aLabel6.TabIndex = 25;
            this.aLabel6.Text = "그룹코드";
            // 
            // aLabel4
            // 
            this.aLabel4.AutoSize = true;
            this.aLabel4.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aLabel4.Location = new System.Drawing.Point(7, 8);
            this.aLabel4.Name = "aLabel4";
            this.aLabel4.Size = new System.Drawing.Size(52, 17);
            this.aLabel4.TabIndex = 24;
            this.aLabel4.Text = "그룹 명";
            // 
            // btngroub
            // 
            this.btngroub.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(239)))), ((int)(((byte)(245)))));
            this.btngroub.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btngroub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btngroub.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btngroub.Location = new System.Drawing.Point(479, 8);
            this.btngroub.Name = "btngroub";
            this.btngroub.Size = new System.Drawing.Size(75, 23);
            this.btngroub.TabIndex = 4;
            this.btngroub.Text = "조회";
            this.btngroub.UseVisualStyleBackColor = false;
            this.btngroub.Click += new System.EventHandler(this.Btngroub_Click);
            // 
            // lblGroup
            // 
            this.lblGroup.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblGroup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGroup.errorp = null;
            this.lblGroup.Location = new System.Drawing.Point(310, 6);
            this.lblGroup.Name = "lblGroup";
            this.lblGroup.Size = new System.Drawing.Size(148, 23);
            this.lblGroup.TabIndex = 1;
            this.lblGroup.txtType = Axxen.CustomControls.type.Normal;
            // 
            // cbbGroup
            // 
            this.cbbGroup.FormattingEnabled = true;
            this.cbbGroup.Location = new System.Drawing.Point(65, 6);
            this.cbbGroup.Name = "cbbGroup";
            this.cbbGroup.Size = new System.Drawing.Size(167, 23);
            this.cbbGroup.TabIndex = 0;
            this.cbbGroup.SelectedIndexChanged += new System.EventHandler(this.CbbGroup_SelectedIndexChanged);
            // 
            // aPanel7
            // 
            this.aPanel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.aPanel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.aPanel7.Controls.Add(this.aLabel3);
            this.aPanel7.Dock = System.Windows.Forms.DockStyle.Left;
            this.aPanel7.Location = new System.Drawing.Point(0, 0);
            this.aPanel7.Name = "aPanel7";
            this.aPanel7.Size = new System.Drawing.Size(128, 40);
            this.aPanel7.TabIndex = 24;
            // 
            // aLabel3
            // 
            this.aLabel3.AutoSize = true;
            this.aLabel3.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aLabel3.Location = new System.Drawing.Point(74, 7);
            this.aLabel3.Name = "aLabel3";
            this.aLabel3.Size = new System.Drawing.Size(42, 21);
            this.aLabel3.TabIndex = 23;
            this.aLabel3.Text = "그룹";
            // 
            // btnInsert
            // 
            this.btnInsert.BackColor = System.Drawing.Color.White;
            this.btnInsert.FlatAppearance.BorderSize = 0;
            this.btnInsert.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInsert.Image = ((System.Drawing.Image)(resources.GetObject("btnInsert.Image")));
            this.btnInsert.Location = new System.Drawing.Point(425, 294);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(54, 51);
            this.btnInsert.TabIndex = 29;
            this.btnInsert.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnInsert.UseVisualStyleBackColor = false;
            this.btnInsert.Click += new System.EventHandler(this.BtnInsert_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.BackColor = System.Drawing.Color.White;
            this.btnRemove.FlatAppearance.BorderSize = 0;
            this.btnRemove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemove.Image = ((System.Drawing.Image)(resources.GetObject("btnRemove.Image")));
            this.btnRemove.Location = new System.Drawing.Point(425, 400);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(54, 51);
            this.btnRemove.TabIndex = 30;
            this.btnRemove.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.Click += new System.EventHandler(this.BtnRemove_Click);
            // 
            // aLabel7
            // 
            this.aLabel7.AutoSize = true;
            this.aLabel7.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aLabel7.Location = new System.Drawing.Point(436, 348);
            this.aLabel7.Name = "aLabel7";
            this.aLabel7.Size = new System.Drawing.Size(34, 17);
            this.aLabel7.TabIndex = 31;
            this.aLabel7.Text = "추가";
            // 
            // aLabel8
            // 
            this.aLabel8.AutoSize = true;
            this.aLabel8.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aLabel8.Location = new System.Drawing.Point(436, 454);
            this.aLabel8.Name = "aLabel8";
            this.aLabel8.Size = new System.Drawing.Size(34, 17);
            this.aLabel8.TabIndex = 32;
            this.aLabel8.Text = "삭제";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(6, 122);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 22);
            this.pictureBox1.TabIndex = 34;
            this.pictureBox1.TabStop = false;
            // 
            // aLabel9
            // 
            this.aLabel9.AutoSize = true;
            this.aLabel9.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aLabel9.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.aLabel9.Location = new System.Drawing.Point(31, 123);
            this.aLabel9.Name = "aLabel9";
            this.aLabel9.Size = new System.Drawing.Size(74, 21);
            this.aLabel9.TabIndex = 33;
            this.aLabel9.Text = "화면목록";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(485, 122);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(23, 22);
            this.pictureBox3.TabIndex = 36;
            this.pictureBox3.TabStop = false;
            // 
            // aLabel10
            // 
            this.aLabel10.AutoSize = true;
            this.aLabel10.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.aLabel10.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.aLabel10.Location = new System.Drawing.Point(510, 123);
            this.aLabel10.Name = "aLabel10";
            this.aLabel10.Size = new System.Drawing.Size(112, 21);
            this.aLabel10.TabIndex = 35;
            this.aLabel10.Text = "추가 화면목록";
            // 
            // aPanel8
            // 
            this.aPanel8.Controls.Add(this.aPanel3);
            this.aPanel8.Controls.Add(this.aPanel2);
            this.aPanel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.aPanel8.Location = new System.Drawing.Point(0, 81);
            this.aPanel8.Name = "aPanel8";
            this.aPanel8.Size = new System.Drawing.Size(1297, 40);
            this.aPanel8.TabIndex = 37;
            // 
            // dgvUseScreen
            // 
            this.dgvUseScreen.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvUseScreen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvUseScreen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUseScreen.Location = new System.Drawing.Point(485, 147);
            this.dgvUseScreen.Name = "dgvUseScreen";
            this.dgvUseScreen.RowTemplate.Height = 23;
            this.dgvUseScreen.Size = new System.Drawing.Size(812, 590);
            this.dgvUseScreen.TabIndex = 41;
            this.dgvUseScreen.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DgvUseScreen_CellMouseDoubleClick);
            // 
            // MSS_CON_002_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.ClientSize = new System.Drawing.Size(1297, 780);
            this.Controls.Add(this.dgvUseScreen);
            this.Controls.Add(this.aPanel8);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.aLabel10);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.aLabel9);
            this.Controls.Add(this.aLabel8);
            this.Controls.Add(this.aLabel7);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.aPanel5);
            this.Controls.Add(this.aPanel4);
            this.Controls.Add(this.dgvNotUseScreen);
            this.Controls.Add(this.aPanel1);
            this.Name = "MSS_CON_002_1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "화면조회";
            this.Load += new System.EventHandler(this.MSS_CON_002_1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.aPanel1.ResumeLayout(false);
            this.aPanel1.PerformLayout();
            this.aPanel2.ResumeLayout(false);
            this.aPanel2.PerformLayout();
            this.aPanel3.ResumeLayout(false);
            this.aPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNotUseScreen)).EndInit();
            this.aPanel4.ResumeLayout(false);
            this.aPanel5.ResumeLayout(false);
            this.aPanel6.ResumeLayout(false);
            this.aPanel6.PerformLayout();
            this.aPanel7.ResumeLayout(false);
            this.aPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.aPanel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUseScreen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CustomControls.ALabel aLabel5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private CustomControls.ALabel aLabel2;
        private CustomControls.APanel aPanel1;
        private CustomControls.APanel aPanel2;
        private CustomControls.ALabel aLabel1;
        private CustomControls.APanel aPanel3;
        private CustomControls.AButton btnScreenSearch;
        private CustomControls.ATextBox txtSearch;
        private System.Windows.Forms.RadioButton rdoScreenCode;
        private System.Windows.Forms.RadioButton rdoScreenName;
        private CustomControls.ADataGridView dgvNotUseScreen;
        private CustomControls.APanel aPanel4;
        private CustomControls.APanel aPanel5;
        private CustomControls.APanel aPanel6;
        private CustomControls.ATextBox lblGroup;
        private CustomControls.AComboBox cbbGroup;
        private CustomControls.APanel aPanel7;
        private CustomControls.ALabel aLabel3;
        private CustomControls.ALabel aLabel6;
        private CustomControls.ALabel aLabel4;
        private CustomControls.AButton btngroub;
        private CustomControls.AButton btnInsert;
        private CustomControls.AButton btnRemove;
        private CustomControls.ALabel aLabel7;
        private CustomControls.ALabel aLabel8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private CustomControls.ALabel aLabel9;
        private System.Windows.Forms.PictureBox pictureBox3;
        private CustomControls.ALabel aLabel10;
        private CustomControls.APanel aPanel8;
        private CustomControls.AButton aButton3;
        private CustomControls.AButton btnSave;
        private CustomControls.ADataGridView dgvUseScreen;
    }
}
